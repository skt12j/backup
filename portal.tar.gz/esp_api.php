<?php
// esp_api.php - OPENWRT RAM-DISK EDITION
require_once __DIR__ . '/core.php';

header('Content-Type: application/json');

// 1. Get User Counts
$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$active = 0; $paused = 0; $passive = 0;
foreach ($sessions as $mac => $data) {
    if (($data['status'] ?? '') === 'active') $active++;
    elseif (($data['status'] ?? '') === 'paused') $paused++;
    else $passive++;
}
$total_users = $active + $paused + $passive;

// 2. Get Sales (Data mode tracking removed to save CPU)
$income = is_numeric(pullFromVault('sales.txt')) ? (float)pullFromVault('sales.txt') : 0;
$total_gb = 0; 

// 3. Get Router Temp (Native OpenWrt)
$ctu = 0; // Ubuntu laptop is gone!
$router_temp = @exec("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null");
$ctr = is_numeric($router_temp) ? round($router_temp / 1000, 1) : 0;

// 4. Internet Check
$internet = false;
if ($fp = @fsockopen("1.1.1.1", 53, $errno, $errstr, 1)) {
    $internet = true;
    fclose($fp);
}

// 5. Deliver Payload
echo json_encode([
    'CTU' => $ctu,
    'CTR' => $ctr,
    'A' => $active,
    'PA' => $paused,
    'P' => $passive,
    'T' => $total_users,
    'INC' => $income,
    'GB' => $total_gb,
    'INT' => $internet
]);
?>