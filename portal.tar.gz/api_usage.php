<?php
// api_usage.php - OPENWRT RAM-DISK EDITION (Time-Based Executioner)
require_once __DIR__ . '/core.php';

if (session_status() === PHP_SESSION_ACTIVE) { session_write_close(); }

$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$changed = false;
$current_time = time();

foreach ($sessions as $mac => $data) {
    if (($data['status'] ?? '') === 'active') {
        
        // 🔥 THE INSTANT GUILLOTINE: TIME CUTOFF LOGIC 🔥
        $active_mode = $data['active_mode'] ?? 'Time';
        $is_empty = false;
        $details = "";

        // We only process Time mode since Data mode requires heavy 'tc' packages
        if ($active_mode === 'Time') {
            $expires = $data['expires'] ?? 0;
            if ($expires > 0 && $current_time >= $expires) {
                $is_empty = true;
                $details = "Time limit reached.";
            }
        }

        if ($is_empty) {
            $client_ip = $data['ip'] ?? '';
            fw_drop($mac, $client_ip); // 🔥 INSTANTLY DROP AND SNAP CONNTRACK 🔥
            
            $sessions[$mac]['status'] = 'expired';
            $sessions[$mac]['time_left'] = 0;
            $sessions[$mac]['last_expired_at'] = $current_time;
            $changed = true;

            $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
            array_unshift($logs, [
                'date' => date('Y-m-d H:i:s'), 
                'mac' => $mac, 
                'event' => 'SESSION_TERMINATED', 
                'tier' => $data['tier'] ?? 'Regular', 
                'details' => $details, 
                'revenue' => 0
            ]);
            // Keep logs light for the router memory
            if (count($logs) > 1000) $logs = array_slice($logs, 0, 1000);
            pushToVault('logs.json', json_encode($logs));
        }
    }
}

// 6. 🔥 SAVE SAFELY TO THE PERMANENT FLASH DATABASE
if ($changed) {
    pushToVault('sessions.json', json_encode($sessions));
    @chmod(DB_DIR . 'sessions.json', 0777);
}

echo "VAULT OS: TIME USAGE SYNC COMPLETE.";
?>