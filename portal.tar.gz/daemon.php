<?php
// daemon.php - OPENWRT RAM-DISK EDITION
set_time_limit(0);
require_once __DIR__ . '/core.php';

// 🔥 FIXED: Ensure the RAM-disk DB folder actually exists before we try to lock it!
if (!file_exists(DB_DIR)) {
    @mkdir(DB_DIR, 0777, true);
}

$lock_file = DB_DIR . 'vaultos_daemon.lock';
$lock_fp = @fopen($lock_file, 'c');

if (!$lock_fp || !flock($lock_fp, LOCK_EX | LOCK_NB)) {
    echo "[VAULT OS] Daemon is already running or locked. Aborting duplicate instance.\n";
    exit;
}

echo "[VAULT OS] Master Engine Started. Executing Expirations and Watching for Zombies...\n";

while (true) {
    // 1. 🔥 TRIGGER THE EXECUTIONER SERVER-SIDE 
    // FIXED: Used __DIR__ so the path never breaks even if the folder name changes!
    $api_script = escapeshellarg(__DIR__ . '/api_usage.php');
    exec("php-cgi -q $api_script > /dev/null 2>&1");

    // 2. PURGE ANCIENT ZOMBIES (3-Day Inactive Cleanup)
    $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
    $sessions_changed = false;
    $current_time = time();

    foreach ($sessions as $mac => $data) {
        $status = $data['status'] ?? '';
        
        if ($status === 'paused' || $status === 'expired' || $status === 'inactive') {
            $reference_time = $data['last_paused_at'] ?? ($data['last_expired_at'] ?? ($data['expires'] ?? 0));

            if ($reference_time <= 0) {
                $sessions[$mac]['last_expired_at'] = $current_time;
                $sessions_changed = true;
                continue; 
            }

            if (($current_time - $reference_time) > 259200) {
                $has_pending_coins = isset($data['pending_coins']) && $data['pending_coins'] > 0;
                if (!$has_pending_coins) {
                    unset($sessions[$mac]);
                    $sessions_changed = true;
                }
            }
        }
    }

    if ($sessions_changed) {
        pushToVault('sessions.json', json_encode($sessions));
        @chmod(DB_DIR . 'sessions.json', 0777); 
    }

    // 🔥 THE REAL-TIME FIX: Sleep for only 1 second instead of 5! 🔥
    sleep(1); 
}

flock($lock_fp, LOCK_UN);
fclose($lock_fp);
?>