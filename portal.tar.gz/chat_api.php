<?php
// chat_api.php - OPENWRT RAM-DISK EDITION
require_once __DIR__ . '/core.php';
header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// --- 1. FETCH CHAT HISTORY ---
if ($action === 'get_history') {
    $mac = $_GET['mac'] ?? '';
    $chats = json_decode(pullFromVault('chats.json'), true) ?: [];
    echo json_encode(['status' => 'success', 'history' => $chats[$mac] ?? []]);
    exit;
}

// --- 2. RAM-DISK FILE UPLOADER ENGINE ---
if ($action === 'upload_photo') {
    $upload_dir = __DIR__ . '/uploads/chats/';
    if (!file_exists($upload_dir)) { mkdir($upload_dir, 0777, true); }
    
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
        
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $filename = 'img_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_dir . $filename)) {
                echo json_encode(['status' => 'success', 'url' => '/uploads/chats/' . $filename]);
                exit;
            }
        }
    }
    echo json_encode(['status' => 'error', 'msg' => 'Invalid or missing file.']);
    exit;
}

// --- 3. SEND MESSAGE ENGINE (REPLACES WEBSOCKETS) ---
if ($action === 'send_msg') {
    $mac = $_POST['mac'] ?? '';
    $name = $_POST['name'] ?? 'Client';
    $msg = $_POST['msg'] ?? '';
    
    if ($mac && $msg) {
        $chats = json_decode(pullFromVault('chats.json'), true) ?: [];
        $names = json_decode(pullFromVault('chat_names.json'), true) ?: [];
        
        if (!isset($chats[$mac])) $chats[$mac] = [];
        $chats[$mac][] = [
            'id' => 'msg_' . time() . '_' . rand(100,999),
            'sender' => 'client',
            'msg' => $msg,
            'time' => date('h:i A')
        ];
        
        // Keep history light for the router's memory (Max 50 messages per user)
        if (count($chats[$mac]) > 50) {
            $chats[$mac] = array_slice($chats[$mac], -50);
        }
        
        $names[$mac] = $name;
        
        pushToVault('chats.json', json_encode($chats));
        pushToVault('chat_names.json', json_encode($names));
        
        echo json_encode(['status' => 'success']);
        exit;
    }
    echo json_encode(['status' => 'error', 'msg' => 'Missing data.']);
    exit;
}

echo json_encode(['status' => 'error', 'msg' => 'Unknown Action.']);
?>