<?php
// restore.php - OPENWRT RAM-DISK EDITION
require_once __DIR__ . '/core.php';

$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$now = time();
$restored_count = 0;

foreach($sessions as $mac => $data) {
    if (($data['status'] ?? '') === 'active') {
        $ip = $data['ip'] ?? '';
        $tier = $data['tier'] ?? 'Regular';
        $mode = $data['active_mode'] ?? 'Time';
        $should_restore = false;

        // 🧠 Check Time Mode Users
        if ($mode === 'Time') {
            if (($data['expires'] ?? 0) > $now) {
                $should_restore = true;
            }
        } 

        // 🟢 If they pass the checks, inject them back into the OpenWrt Firewall!
        if ($should_restore) {
            fw_allow($mac, $ip, $tier);
            $restored_count++;
        } else {
            // Edge Case: If they were marked active but actually expired during the reboot, correct the Vault!
            $sessions[$mac]['status'] = 'expired';
            $sessions[$mac]['time_left'] = 0;
            $sessions[$mac]['last_expired_at'] = $now;
        }
    }
}

// Save any corrections made during the audit
pushToVault('sessions.json', json_encode($sessions));

echo "VAULT OS: Restored $restored_count active sessions to the OpenWrt Firewall.";
?>