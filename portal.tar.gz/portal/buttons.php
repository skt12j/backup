<?php
// portal/buttons.php - OPENWRT RAM-DISK EDITION (Time Mode Only)

$button_section = $button_section ?? ''; 

if (!defined('VAULT_BUTTONS_ASSETS_LOADED')): 
    define('VAULT_BUTTONS_ASSETS_LOADED', true);
?>

<script>
    function startHackerCodeBuy() {
        if (typeof openSlot === 'function') {
            openSlot('buy_voucher');
        } else {
            let modeModal = document.getElementById('m-mode-select');
            if (modeModal) modeModal.style.display = 'block';
            else if (typeof openM === 'function') openM('m-mode-select'); 
        }
    }
</script>

<style>
    @keyframes spin-cw { 100% { transform: translate(-50%, -50%) rotate(360deg); } }
    @keyframes spin-ccw { 100% { transform: translate(-50%, -50%) rotate(-360deg); } }
    @keyframes pulse-glow { 0%, 100% { filter: drop-shadow(0 0 5px var(--success)); opacity: 0.8; } 50% { filter: drop-shadow(0 0 20px var(--success)); opacity: 1; } }
    @keyframes pulse-glow-gold { 0%, 100% { filter: drop-shadow(0 0 5px var(--warning)); opacity: 0.8; } 50% { filter: drop-shadow(0 0 20px var(--warning)); opacity: 1; } }

    .hud-btn { position: relative; width: 160px; height: 160px; background: transparent; border: none; cursor: pointer; outline: none; transition: transform 0.2s; display: block; margin: 25px auto; }
    .hud-btn:hover { transform: scale(1.05); }
    .hud-ring { position: absolute; top: 50%; left: 50%; border-radius: 50%; transform: translate(-50%, -50%); pointer-events: none; }
    .hud-outer { width: 150px; height: 150px; border: 3px dashed var(--success); animation: spin-cw 12s linear infinite, pulse-glow 3s ease-in-out infinite; }
    .hud-inner { width: 120px; height: 120px; border: 4px double var(--success); border-left-color: transparent; border-right-color: transparent; animation: spin-ccw 6s linear infinite; }
    .hud-core { width: 90px; height: 90px; border: 2px solid var(--success); box-shadow: inset 0 0 15px var(--success), 0 0 10px var(--success); opacity: 0.4; animation: spin-cw 20s linear infinite; }
    .hud-text { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: #fff; font-family: 'Orbitron', sans-serif; font-size: 1.1rem; font-weight: 900; text-shadow: 0 0 10px #000, 0 0 20px var(--success); pointer-events: none; line-height: 1.2; width: 100%; z-index: 10; text-align: center; }

    .hud-outer.gold { border-color: var(--warning); animation: spin-cw 12s linear infinite, pulse-glow-gold 3s ease-in-out infinite; }
    .hud-inner.gold { border-color: var(--warning); border-left-color: transparent; border-right-color: transparent; }
    .hud-core.gold { border-color: var(--warning); box-shadow: inset 0 0 15px var(--warning), 0 0 10px var(--warning); }
    .hud-text.gold { text-shadow: 0 0 10px #000, 0 0 20px var(--warning); color: var(--warning); }
    
    .btn-striped-warning {
        background-image: repeating-linear-gradient(0deg, #ea580c, #ea580c 4px, #111 4px, #111 8px) !important;
        color: #fff !important; text-shadow: 1px 1px 2px #000 !important; border: 2px solid #ea580c !important; box-shadow: 0 0 10px #ea580c !important;
    }
</style>
<?php endif; ?>

<?php if ($button_section === 'lobby_main'): ?>
    
    <p style="font-size: 0.9rem; color: #666; margin-bottom: 5px;">SELECT BANDWIDTH TIER:</p>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
        <button id="tr" class="btn active-tier" onclick="setLobbyTier('Regular')">REGULAR</button>
        <button id="tg" class="btn" onclick="setLobbyTier('Gaming')">VIP GAMING</button>
    </div>

    <button class="hud-btn" onclick="openSlot('insert_coin')">
        <div class="hud-ring hud-outer"></div>
        <div class="hud-ring hud-inner"></div>
        <div class="hud-ring hud-core"></div>
        <div class="hud-text">INSERT<br>COIN</div>
    </button>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
        <button class="btn btn-striped-warning" style="font-size: 0.9rem;" onclick="startHackerCodeBuy()">☠️ BUY HACKER CODE</button>
        <button class="btn" style="border-color: var(--theme-color); color: var(--theme-color);" onclick="openVoucher()">HACK KEY</button>
    </div>
    
    <button class="btn" style="border-style: dashed; border-color: #333; color: #888; margin-top: 10px; width: 100%;" onclick="openRates()">VIEW TARIFFS</button>

<?php elseif ($button_section === 'lobby_success'): ?>
    <div style="margin-top: 30px; display: flex; gap: 15px; flex-wrap: wrap; justify-content: center; width: 100%; max-width: 400px;">
        <button class="btn btn-success" style="width: 45%; padding: 12px;" onclick="window.location.href='https://fast.com'">🚀 SPEED TEST</button>
        <button class="btn" style="border-color: var(--theme-color); color: var(--theme-color); width: 45%; padding: 12px;" onclick="window.location.href='/portal/status.php'">📊 DASHBOARD</button>
    </div>

<?php elseif ($button_section === 'lobby_minted'): ?>
    <button class="copy-btn" style="margin-bottom: 15px; border-color: var(--vip); color: var(--vip);" onclick="copyVoucherCode('<?php echo $bought_voucher_code ?? ''; ?>', this)">📋 COPY CODE</button>
    <button class="btn btn-success" style="width: 80%; max-width: 400px; margin-top: 30px; display: block; margin-left: auto; margin-right: auto;" onclick="window.location.href='/portal/index.php'">DONE</button>

<?php elseif ($button_section === 'tier_select'): ?>
    <p style="font-size: 0.9rem; color: #666; margin-bottom: 5px; text-align: left;">NETWORK PROTOCOL VIEWER:</p>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
        <button id="tr" class="btn <?php echo ($active_tier === 'Regular') ? 'active-tier' : ''; ?>" onclick="setMode('Regular')">REGULAR</button>
        <button id="tg" class="btn <?php echo ($active_tier === 'Gaming') ? 'active-tier' : ''; ?>" onclick="setMode('Gaming')">VIP GAMING</button>
    </div>
    
<?php elseif ($button_section === 'action_controls'): ?>
    <div id="active-controls" style="display: block;">
        <button type="button" class="hud-btn" onclick="openSlot('add_coin')" style="margin: 10px auto 25px auto;">
            <div class="hud-ring hud-outer"></div>
            <div class="hud-ring hud-inner"></div>
            <div class="hud-ring hud-core"></div>
            <div class="hud-text" style="font-size: 0.9rem;">+ EXTEND<br>TIME</div>
        </button>

        <!-- 🔥 FIXED: DYNAMIC AUDIO ID FOR THE FREEZE BUTTON 🔥 -->
        <form method="POST" id="state-form" onsubmit="return triggerSubmitLoader(event, this, '<?php echo ($status === 'connected') ? 'FREEZING SESSION' : 'RE-ESTABLISHING UPLINK'; ?>', false, '<?php echo ($status === 'connected') ? 's-freeze' : 's-loading'; ?>');">
            <input type="hidden" name="action" value="<?php echo ($status === 'connected') ? 'pause' : 'resume'; ?>">
            <button type="submit" class="btn <?php echo ($status === 'connected') ? 'btn-danger' : 'btn-success'; ?>" style="width: 100%; border-width: 2px;">
                <?php echo ($status === 'connected') ? '🧊 FREEZE SESSION' : '▶️ RESTORE SESSION'; ?>
            </button>
        </form>
        
        <form method="POST" id="sync-form" onsubmit="return triggerSubmitLoader(event, this, 'BYPASSING FIREWALL', true, 's-loading');">
            <input type="hidden" name="action" value="force_connect">
            <button type="submit" class="btn btn-warning" style="border-width: 2px; width: 100%; margin-top: 10px;" <?php echo ($status === 'paused') ? 'disabled style="opacity:0.3;"' : ''; ?>>🌐 RE-SYNC CONNECTION</button>
        </form>
    </div>

    <div id="switch-controls" style="display: none;">
        <div id="switch-has-balance">
            <button type="button" class="hud-btn" onclick="openSlot('add_coin')" style="margin: 10px auto 25px auto;">
                <div class="hud-ring hud-outer"></div>
                <div class="hud-ring hud-inner"></div>
                <div class="hud-ring hud-core"></div>
                <div class="hud-text" style="font-size: 0.9rem;">ADD TO<br>BANK</div>
            </button>
            <button class="btn btn-success" style="border-width: 2px; width: 100%;" onclick="openSwitchConfirm()">🔌 CONNECT TO THIS TIER</button>
        </div>

        <div id="switch-no-balance" style="display: none;">
            <button type="button" class="hud-btn" onclick="openSlot('add_coin')" style="margin: 10px auto 25px auto;">
                <div class="hud-ring hud-outer gold"></div>
                <div class="hud-ring hud-inner gold"></div>
                <div class="hud-ring hud-core gold"></div>
                <div class="hud-text gold" style="font-size: 0.9rem;">INSERT<br>COIN</div>
            </button>
            <button type="button" class="btn outline" style="border-color: #555; color: #555; width: 100%; cursor: not-allowed;" disabled>
                🚫 ZERO BALANCE
            </button>
        </div>
    </div>

    <div style="margin-top: 25px;">
        <button class="btn btn-striped-warning" style="font-size: 0.8rem; width: 100%;" onclick="startHackerCodeBuy()">☠️ BUY HACKER CODE</button>
    </div>
    
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
        <button class="btn" style="border-color: var(--theme-color); color: var(--theme-color); font-size: 0.8rem;" onclick="openVoucher()">🔐️ HACKER KEY</button>
        <button class="btn" style="border-style: dashed; border-color: #333; color: #888; font-size: 0.8rem;" onclick="openRates()">VIEW TARIFFS</button>
    </div>

<?php elseif ($button_section === 'status_success'): ?>
    <div style="margin-top: 30px; display: flex; gap: 15px; flex-wrap: wrap; justify-content: center; width: 100%; max-width: 400px;">
        <button class="btn btn-success" style="width: 45%; padding: 12px;" onclick="window.location.href='https://fast.com'">🚀 BROWSE FAST.COM</button>
        <button class="btn" style="border-color: var(--theme-color); color: var(--theme-color); width: 45%; padding: 12px;" onclick="window.location.href='/portal/status.php'">📊 GO TO STATUS</button>
    </div>

<?php elseif ($button_section === 'status_topup_success'): ?>
    <div style="margin-top: 30px; display: flex; gap: 15px; flex-wrap: wrap; justify-content: center; width: 100%; max-width: 400px;">
        <?php if($status === 'connected'): ?>
            <button class="btn btn-success" style="width: 45%; padding: 12px;" onclick="window.location.href='https://fast.com'">🚀 SPEED TEST</button>
        <?php endif; ?>
        <button class="btn" style="border-color: var(--theme-color); color: var(--theme-color); width: <?php echo ($status === 'connected')?'45%':'100%'; ?>; padding: 12px;" onclick="window.location.href='/portal/status.php'">📊 DASHBOARD</button>
    </div>

<?php elseif ($button_section === 'status_minted'): ?>
    <button class="copy-btn" style="margin-bottom: 15px; border-color: var(--vip); color: var(--vip);" onclick="copyVoucherCode('<?php echo $bought_voucher_code ?? ''; ?>', this)">🗝️ COPY KEY</button>
    <button class="btn btn-success" style="width: 80%; max-width: 400px; margin-top: 30px; display: block; margin-left: auto; margin-right: auto;" onclick="window.location.href='/portal/status.php'">DONE</button>

<?php elseif ($button_section === 'frozen_resume'): ?>
    <button class="btn" style="background: #00f3ff; color: #000; font-weight: 900; width: 80%; max-width: 400px; margin-top: 30px; box-shadow: 0 0 20px #00f3ff;" onclick="window.location.href='/portal/status.php'">🧊 GO TO STATUS</button>

<?php elseif ($button_section === 'copy_unused_key'): ?>
    <button class="copy-btn" style="border-color: <?php echo $v_color ?? '#fff'; ?>; color: <?php echo $v_color ?? '#fff'; ?>;" onclick="copyVoucherCode('<?php echo htmlspecialchars($v_code ?? ''); ?>', this)">COPY</button>

<?php elseif ($button_section === 'modal_submit'): ?>
    <button type="submit" class="btn" style="background: var(--theme-color); color: #000; font-weight: 900; margin-top: 15px; border: none;">ACTIVATE KEY</button>

<?php elseif ($button_section === 'modal_cancel'): ?>
    <button type="button" class="btn" onclick="closeM(this.closest('.modal').id)" style="border: 1px dashed #555; color: #888; margin-top: 10px; width: 100%;">CANCEL</button>

<?php elseif ($button_section === 'modal_purge'): ?>
    <button type="submit" class="btn btn-danger" style="font-weight: 900; margin-top: 15px;">YES, WIPE MY BALANCE & SWITCH</button>

<?php elseif ($button_section === 'modal_jump'): ?>
    <button type="submit" class="btn btn-warning" style="color: #000; font-weight: 900; margin-top: 15px;">EXECUTE JUMP</button>

<?php elseif ($button_section === 'modal_ack'): ?>
    <button type="button" class="btn btn-danger" onclick="closeM('m-alert')">ACKNOWLEDGE</button>

<?php elseif ($button_section === 'coin_mode_select'): ?>
    <style>
        .btn-bomb {
            position: relative; background-color: #111; border: 2px solid #ea580c; 
            box-shadow: inset 0 0 10px rgba(234, 88, 12, 0.1), 0 0 15px rgba(234, 88, 12, 0.4);
            overflow: hidden; padding: 20px; font-size: 1.2rem; display: flex; flex-direction: column; align-items: center; gap: 10px; margin-bottom: 15px; width: 100%;
        }
        .btn-bomb .clock-face {
            background-color: #000; color: #ea580c; font-family: 'Orbitron', monospace; padding: 5px 15px; border: 1px solid #333; border-radius: 4px; text-shadow: 0 0 10px #ea580c; letter-spacing: 2px; font-size: 1.3rem; font-weight: 700;
        }
    </style>
    <button type="button" class="btn btn-bomb" onclick="confirmMode('Time')">
        <div class="clock-face" id="dynamic-bomb-clock">00:05:00</div>
        <span style="color: #fff; z-index: 2; position: relative; font-weight: bold;">BUY TIME LIMIT</span>
    </button>
    <script>
        (function() {
            let clockElem = document.getElementById('dynamic-bomb-clock');
            if(!clockElem) return;
            let timeRemaining = 300; 
            if(window.bombClockInterval) clearInterval(window.bombClockInterval);
            window.bombClockInterval = setInterval(() => {
                timeRemaining--;
                if(timeRemaining < 0) timeRemaining = 300; 
                let m = Math.floor(timeRemaining / 60).toString().padStart(2, '0');
                let s = (timeRemaining % 60).toString().padStart(2, '0');
                clockElem.innerText = `00:${m}:${s}`;
            }, 1000); 
        })();
    </script>

<?php elseif ($button_section === 'coin_tier_tabs'): ?>
    <button type="button" id="m-btn-reg" class="modal-tab active" onclick="setModalTier('Regular')">REGULAR</button>
    <button type="button" id="m-btn-gam" class="modal-tab" onclick="setModalTier('Gaming')">GAMING</button>

<?php elseif ($button_section === 'coin_dynamic_submit'): ?>
    <style>
        @keyframes moving-danger-stripes { 0% { background-position: 0 0; } 100% { background-position: 50px 50px; } }
        .btn-dynamic-cancel {
            background-image: linear-gradient(135deg, rgba(220, 38, 38, 0.9) 25%, rgba(0, 0, 0, 0.3) 25%, rgba(0, 0, 0, 0.3) 50%, rgba(220, 38, 38, 0.9) 50%, rgba(220, 38, 38, 0.9) 75%, rgba(0, 0, 0, 0.3) 75%, rgba(0, 0, 0, 0.3) 100%);
            background-size: 50px 50px; animation: moving-danger-stripes 1s linear infinite; border-color: #f87171; color: #fff; text-shadow: 0 0 5px #000; box-shadow: 0 0 15px rgba(239, 68, 68, 0.5); width: 100%;
        }
        .btn-dynamic-submit { width: 100%; }
    </style>
    <button type="button" id="coin-submit-btn" class="btn btn-dynamic-cancel" onclick="stopSlot()" style="width: 100%;">CANCEL</button>

<?php elseif ($button_section === 'coin_pending_choices'): ?>
    <button class="btn btn-warning" onclick="handlePendingChoice('discard')" style="font-weight: 900; border-width: 2px;">DISCARD & RESTART</button>
    <!-- 🔥 FIXED: REMOVED CHAT REFERENCE 🔥 -->
    <button class="btn" style="border-style: dashed; color: #888; border-color: #555;" onclick="handlePendingChoice('keep')">KEEP FOR LATER</button>

<?php elseif ($button_section === 'expired_jump'): ?>
    <button type="submit" class="btn outline" style="width: 100%; border-color: var(--warning); color: var(--warning); box-shadow: inset 0 0 10px rgba(255,193,7,0.2);">⚡ JUMP TO ACTIVE VAULT TIER</button>
    
<?php elseif ($button_section === 'expired_extend'): ?>
    <button type="button" class="hud-btn" onclick="openSlot('add_coin')" style="margin: 10px auto 25px auto;">
        <div class="hud-ring hud-outer"></div>
        <div class="hud-ring hud-inner"></div>
        <div class="hud-ring hud-core"></div>
        <div class="hud-text" style="font-size: 0.9rem;">+ EXTEND<br>TIME</div>
    </button>

<?php elseif ($button_section === 'expired_view_traffic'): ?>
    <button type="submit" class="btn outline" style="width: 100%; border-color: #888; color: #888; font-size: 0.8rem; margin-top: 5px;">📊 VIEW TRAFFIC / BACK TO LOBBY</button>

<?php elseif ($button_section === 'voucher_conflict'): ?>
    <button type="submit" class="btn btn-success" style="font-weight: 900; width: 100%; border-width: 2px;">CONTINUE? ▶️</button>
    <button type="button" class="btn btn-danger" onclick="closeM('m-voucher-conflict')" style="font-weight: bold; width: 100%; margin-top: 10px;">CANCEL 🛑</button>
<?php endif; ?>