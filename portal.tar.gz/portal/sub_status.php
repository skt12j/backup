<?php
// portal/sub_status.php - OPENWRT RAM-DISK EDITION (Pure CSS / Time Mode)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

$client_ip = $_SERVER['REMOTE_ADDR'];
$client_mac = strtolower(getClientMac($client_ip)); 

// 🔥 INSTANT WISP FIREWALL UNLOCK 🔥
exec("nft add element inet pisowifi wisp_macs { $client_mac } 2>/dev/null");

// 📡 LIVE INTERNET PING CHECK (SERVER-SIDE)
if (isset($_GET['ping_check'])) {
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    $fp = @fsockopen("1.1.1.1", 53, $errno, $errstr, 1);
    if ($fp) { fclose($fp); echo json_encode(['internet' => true]); } 
    else { echo json_encode(['internet' => false]); }
    exit;
}

// Fetch the WISP Database safely from Vault
$subs = json_decode(pullFromVault('subscriptions.json'), true) ?: [];
$my_sub = null;

foreach ($subs as $id => $sub) {
    $macs_lower = array_map('strtolower', $sub['macs'] ?? []);
    if (in_array($client_mac, $macs_lower)) {
        $my_sub = $sub;
        $_SESSION['wisp_authenticated_mac'] = $client_mac; 
        break;
    }
}

// Failsafe: Check session lock before kicking to lobby
if (!$my_sub && ($_SESSION['wisp_authenticated_mac'] ?? '') !== $client_mac) {
    header("Location: index.php"); 
    exit;
}

if (!$my_sub) {
    foreach ($subs as $sub) {
        $my_sub = $sub; break;
    }
    if (!$my_sub) { $my_sub = ['name' => 'VIP SUBSCRIBER', 'expires_at' => time() + 86400, 'macs' => [$client_mac]]; }
}

$current_time = time();
$expires_at = $my_sub['expires_at'];
$created_at = $my_sub['created_at'] ?? ($expires_at - (30 * 86400));
$is_expired = ($expires_at <= $current_time || ($my_sub['status'] ?? '') === 'expired');

$resync_success = false;

// 🔥 THE OPENWRT RESYNC ACTION HANDLER 🔥
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'resync' && !$is_expired) {
        exec("nft add element inet pisowifi wisp_macs { $client_mac } 2>/dev/null");
        
        $safe_ip = escapeshellarg($client_ip);
        exec("conntrack -D -s $safe_ip 2>/dev/null");
        exec("conntrack -D -d $safe_ip 2>/dev/null");
        
        $resync_success = true;
    }
}

// 🔥 FIXED: DYNAMIC IP NOW SHOWS ACTUAL LIVE NETWORK DATA 🔥
$device_ip = $client_ip; 
$gateway_ip = $_SERVER['SERVER_ADDR'] ?? '10.0.0.1';
$internet_speed = $my_sub['speed'] ?? 'MAX';

$hour = date('H');
if ($hour < 12) { $greeting = "Good morning!"; }
elseif ($hour < 18) { $greeting = "Good afternoon!"; }
else { $greeting = "Good evening!"; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>VAULT OS | SUBSCRIBER PORTAL</title>
    <?php include 'theme.php'; ?>
    <style>
        body { background: #0a0c10 !important; color: #fff; }
        
        .premium-card { background: #13151c; border: 1px solid #2a2d36; border-radius: 16px; padding: 25px; width: 100%; max-width: 500px; box-shadow: 0 10px 40px rgba(0,0,0,0.8); position: relative; z-index: 10; }

        .dash-header { display: flex; flex-direction: column; margin-bottom: 25px; }
        .greeting { color: #8a8d98; font-size: 0.9rem; font-weight: bold; margin-bottom: 8px; }
        .acc-box { background: #1a1d27; border-radius: 12px; padding: 15px; display: flex; align-items: center; gap: 15px; }
        .acc-icon { background: rgba(255,255,255,0.05); padding: 10px; border-radius: 8px; font-size: 1.2rem; }
        .acc-info { display: flex; flex-direction: column; }
        .acc-lbl { font-size: 0.7rem; color: #8a8d98; font-family: 'Orbitron'; letter-spacing: 1px; }
        .acc-name { font-size: 1.2rem; font-family: 'Rajdhani'; font-weight: bold; color: #fff; text-transform: uppercase; }

        .dash-body { display: flex; flex-direction: row; gap: 15px; align-items: center; border-bottom: 1px solid #2a2d36; padding-bottom: 25px; margin-bottom: 25px; }

        .timer-container { position: relative; width: 160px; height: 160px; flex-shrink: 0; }
        .progress-ring { transform: rotate(-90deg); width: 100%; height: 100%; }
        .progress-ring__bg { fill: transparent; stroke: #1a1d27; stroke-width: 8; }
        .progress-ring__circle { fill: transparent; stroke: #10b981; stroke-width: 8; stroke-linecap: round; transition: stroke-dashoffset 0.5s ease, stroke 0.5s ease; }
        
        .timer-content { position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        
        .status-pill { background: rgba(16, 185, 129, 0.1); color: #10b981; padding: 3px 10px; border-radius: 12px; font-size: 0.65rem; font-family: 'Orbitron'; font-weight: bold; margin-bottom: 5px; transition: all 0.5s ease; }

        .time-main { font-size: 2.1rem; font-family: 'Rajdhani'; font-weight: 900; line-height: 1; display: flex; align-items: center; justify-content: center; gap: 4px; letter-spacing: 1px; }
        .time-val { color: #fff; transition: color 0.3s; }
        .time-colon { color: #fff; margin-bottom: 4px; font-size: 1.8rem; }
        .blink-colon { animation: colonBlink 1s infinite; }
        
        @keyframes colonBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.2; } }

        .time-labels { display: flex; justify-content: space-between; width: 55%; font-size: 0.65rem; color: #8a8d98; font-family: 'Orbitron'; letter-spacing: 1px; margin-top: 5px; }

        .info-section { flex-grow: 1; display: flex; flex-direction: column; gap: 10px; }
        .info-title { font-size: 0.75rem; color: #8a8d98; font-family: 'Orbitron'; }
        .info-val { display: flex; align-items: center; gap: 8px; font-size: 1.1rem; font-family: 'Rajdhani'; font-weight: bold; transition: color 0.3s; }

        .detail-row { display: flex; justify-content: space-between; font-size: 0.85rem; font-family: 'Source Code Pro'; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 4px; }
        .detail-lbl { color: #8a8d98; }

        .btn-resubscribe { background: linear-gradient(90deg, #ff4e33, #ff7b00); color: #fff; border: none; padding: 12px; border-radius: 8px; font-family: 'Orbitron'; font-weight: bold; cursor: pointer; width: 100%; box-shadow: 0 4px 15px rgba(255, 123, 0, 0.3); margin-top: 10px; transition: transform 0.2s; }
        .btn-resubscribe:hover { transform: scale(1.02); }

        .btn-group { display: flex; gap: 10px; margin-top: 15px; }
        .btn-outline { background: transparent; color: #fff; border: 1px solid #444; padding: 10px; border-radius: 8px; font-family: 'Orbitron'; font-size: 0.8rem; flex: 1; cursor: pointer; transition: all 0.2s; }
        .btn-outline:hover { background: #222; border-color: #666; }
        
        .footer-note { font-size: 0.8rem; color: #8a8d98; text-align: center; margin-bottom: 15px; line-height: 1.4; }

        .result-cursor { display: inline-block; width: 8px; height: 15px; animation: blink 1s step-end infinite; vertical-align: middle; margin-left: 2px; margin-top: -2px; }
        @keyframes blink { 50% { opacity: 0; } }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        
        .offline-pulse { animation: offlineBlink 1.5s infinite; }
        @keyframes offlineBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; color: #ff4c4c; } }
    </style>
</head>
<body>

    <!-- RESYNC SUCCESS SCREEN -->
    <?php if ($resync_success): ?>
        <div id="loader-success" style="display:flex; flex-direction: column; justify-content: center; align-items: center; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; z-index: 10000;">
            <div style="font-size: 5rem; text-shadow: 0 0 20px var(--success);">🔓🌐</div>
            <h2 style="color: var(--success); font-size: 2.2rem; font-family: 'Orbitron'; text-shadow: 0 0 20px var(--success); text-align:center;">UPLINK RESTORED</h2>
            <div class="terminal-log" style="width: 80%; max-width: 400px; color: var(--success); border: 1px solid var(--success); background: rgba(0,0,0,0.8); text-align: left; padding:15px; margin-top:20px; font-family: 'Source Code Pro'; font-size: 0.9rem;">
                <span id="term-granted"></span><span class="result-cursor" style="background-color: var(--success);"></span>
            </div>
            <div style="margin-top: 30px; display: flex; gap: 15px; flex-wrap: wrap; justify-content: center; width: 100%; max-width: 400px;">
                <button class="btn btn-success" style="width: 45%; padding: 12px;" onclick="window.location.href='https://fast.com'">🚀 SPEED TEST</button>
                <button class="btn" style="border-color: var(--theme-color); color: var(--theme-color); width: 45%; padding: 12px;" onclick="window.location.href='sub_status.php'">📊 DASHBOARD</button>
            </div>
        </div>
        <script>
            window.addEventListener('DOMContentLoaded', () => {
                var lines = ["> BYPASSING CAPTIVE PORTAL...", "> FIREWALL_TUNNEL: SECURED", "> ROUTING_TRAFFIC_TO_CORE...", "> INTERNET_ACCESS_GRANTED"];
                var el = document.getElementById('term-granted'); var curr = 0;
                function t() { if(curr<lines.length) { el.innerHTML += lines[curr]+"<br>"; curr++; setTimeout(t, Math.random()*200+200); } }
                setTimeout(t, 400);
                setTimeout(() => { window.location.href = 'sub_status.php'; }, 3500);
            });
        </script>
    <?php exit; endif; ?>

    <div id="m-loading" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 99999; flex-direction: column; align-items: center; justify-content: center;">
        <div style="border: 4px solid rgba(0, 243, 255, 0.1); border-top: 4px solid #00f3ff; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite; margin-bottom: 20px;"></div>
        <h2 style="color: #00f3ff; font-family: 'Orbitron'; letter-spacing: 2px;">RE-ESTABLISHING UPLINK...</h2>
    </div>

    <!-- MAIN DASHBOARD -->
    <div class="container" style="display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:80vh; padding: 20px;">
        <img src="../assets/logo.png" style="max-width: 100px; filter: drop-shadow(0 0 10px #10b981); margin-bottom:20px; z-index:10;">
        
        <div class="premium-card">
            
            <div class="dash-header">
                <div class="greeting"><?php echo $greeting; ?></div>
                <div class="acc-box">
                    <div class="acc-icon">👤</div>
                    <div class="acc-info">
                        <span class="acc-lbl">WISP SUBSCRIBER</span>
                        <span class="acc-name"><?php echo htmlspecialchars($my_sub['name'] ?? 'VIP'); ?></span>
                    </div>
                </div>
            </div>

            <div class="dash-body">
                <div class="timer-container">
                    <svg class="progress-ring" width="160" height="160">
                        <circle class="progress-ring__bg" cx="80" cy="80" r="70"></circle>
                        <circle class="progress-ring__circle" cx="80" cy="80" r="70" id="ring-path"></circle>
                    </svg>
                    <div class="timer-content">
                        <div id="ring-status" class="status-pill">● CALCULATING</div>
                        
                        <div class="time-main">
                            <span id="t-v1" class="time-val">00</span>
                            <span class="time-colon blink-colon">:</span>
                            <span id="t-v2" class="time-val">00</span>
                        </div>
                        <div class="time-labels">
                            <span id="t-l1">MIN</span>
                            <span id="t-l2">SEC</span>
                        </div>
                    </div>
                </div>

                <div class="info-section">
                    <div class="info-title">STATUS</div>
                    <div class="info-val" id="text-status">
                        <?php echo $is_expired ? '<i style="color:#ff4c4c;">🚫</i> <span style="color:#ff4c4c;">No active session</span>' : '<i style="color:#10b981;">📶</i> Uplink Active'; ?>
                    </div>
                    
                    <div style="margin-top: 5px;">
                        <div class="detail-row"><span class="detail-lbl">Device IP:</span> <span style="color:#00f3ff; font-weight:bold;"><?php echo htmlspecialchars($device_ip); ?></span></div>
                        <div class="detail-row"><span class="detail-lbl">Gateway:</span> <span id="gateway-status" style="color:#00f3ff;"><?php echo htmlspecialchars($gateway_ip); ?></span></div>
                        <div class="detail-row"><span class="detail-lbl">Internet Speed:</span> <span style="color:var(--vip); font-weight:bold; text-shadow: 0 0 5px rgba(176,38,255,0.5);"><?php echo htmlspecialchars($internet_speed); ?></span></div>
                    </div>
                </div>
            </div>

            <div class="footer-note">
                Your internet access is unrestricted. You do not need to use the Captive Portal.
            </div>

            <button class="btn-resubscribe" onclick="triggerChatWidget()">
                <?php echo $is_expired ? 'RE-SUBSCRIBE NOW' : 'EXTEND CONNECTION'; ?>
            </button>

            <?php if (!$is_expired): ?>
            <div class="btn-group">
                <button class="btn-outline" onclick="window.location.href='https://fast.com'">🚀 SPEED TEST</button>
                <form method="POST" onsubmit="return triggerSubmitLoader(event, this);" style="flex:1; margin:0;">
                    <input type="hidden" name="action" value="resync">
                    <button type="submit" class="btn-outline" style="width:100%; border-color:#00f3ff; color:#00f3ff;">🔄 RESYNC</button>
                </form>
            </div>
            <?php else: ?>
            <div class="btn-group">
                <button class="btn-outline" style="border-color:#ff4c4c; color:#ff4c4c;" onclick="window.location.href='index.php'">🪙 USE COIN SLOT</button>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'chat_widget.php'; ?>

    <script>
        const expiresAt = <?php echo $expires_at; ?>;
        const createdAt = <?php echo $created_at; ?>;
        const totalDuration = expiresAt - createdAt;
        const isExpiredPHP = <?php echo $is_expired ? 'true' : 'false'; ?>;
        const gatewayIp = "<?php echo $gateway_ip; ?>";
        
        let isInternetOnline = true;
        
        const circle = document.getElementById('ring-path');
        const radius = circle.r.baseVal.value;
        const circumference = radius * 2 * Math.PI;
        circle.style.strokeDasharray = `${circumference} ${circumference}`;

        function updateDashboard() {
            const now = Math.floor(Date.now() / 1000);
            let timeLeft = expiresAt - now;
            let isOffline = isExpiredPHP || !isInternetOnline;

            if (timeLeft <= 0) timeLeft = 0;

            let percent = (timeLeft / totalDuration) * 100;
            if (percent > 100) percent = 100;
            if (percent < 0) percent = 0;

            let ringColor = "#ff4c4c"; 
            if (percent >= 75) ringColor = "#10b981"; 
            else if (percent >= 30) ringColor = "#00f3ff"; 
            else if (percent >= 10) ringColor = "#f59e0b"; 

            if (!isInternetOnline || isExpiredPHP) {
                ringColor = "#ff4c4c";
            }

            const offset = circumference - (percent / 100) * circumference;
            circle.style.strokeDashoffset = offset;
            circle.style.stroke = ringColor;

            const statusPill = document.getElementById('ring-status');
            if (isOffline) {
                statusPill.innerHTML = '● OFFLINE';
                statusPill.style.color = '#ff4c4c';
                statusPill.style.background = 'rgba(255, 76, 76, 0.1)';
                document.getElementById('gateway-status').innerHTML = 'OFFLINE';
                document.getElementById('gateway-status').style.color = '#ff4c4c';
            } else {
                statusPill.innerHTML = '● ONLINE';
                statusPill.style.color = ringColor;
                statusPill.style.background = `rgba(${hexToRgb(ringColor)}, 0.1)`;
                document.getElementById('gateway-status').innerHTML = gatewayIp;
                document.getElementById('gateway-status').style.color = '#00f3ff';
            }

            let d = Math.floor(timeLeft / 86400);
            let h = Math.floor((timeLeft % 86400) / 3600);
            let m = Math.floor((timeLeft % 3600) / 60);
            let s = Math.floor(timeLeft % 60);

            let val1 = 0, val2 = 0;
            let lbl1 = "MIN", lbl2 = "SEC";

            if (d >= 365) {
                val1 = Math.floor(d / 365); val2 = Math.floor((d % 365) / 30);
                lbl1 = "YRS"; lbl2 = "MOS";
            } else if (d >= 30) {
                val1 = Math.floor(d / 30); val2 = d % 30;
                lbl1 = "MOS"; lbl2 = "DAY";
            } else if (d > 0) {
                val1 = d; val2 = h;
                lbl1 = "DAY"; lbl2 = "HRS";
            } else if (h > 0) {
                val1 = h; val2 = m;
                lbl1 = "HRS"; lbl2 = "MIN";
            } else {
                val1 = m; val2 = s;
                lbl1 = "MIN"; lbl2 = "SEC";
            }

            document.getElementById('t-v1').innerText = val1.toString().padStart(2, '0');
            document.getElementById('t-v2').innerText = val2.toString().padStart(2, '0');
            document.getElementById('t-l1').innerText = lbl1;
            document.getElementById('t-l2').innerText = lbl2;

            document.getElementById('t-v1').style.color = isOffline ? '#8a8d98' : '#fff';
            document.getElementById('t-v2').style.color = isOffline ? '#8a8d98' : '#fff';
            document.querySelector('.time-colon').style.color = isOffline ? '#8a8d98' : '#fff';
        }

        function hexToRgb(hex) {
            let bigint = parseInt(hex.replace('#',''), 16);
            return `${(bigint >> 16) & 255}, ${(bigint >> 8) & 255}, ${bigint & 255}`;
        }

        function checkServerInternet() {
            fetch('?ping_check=1&t=' + new Date().getTime())
                .then(r => r.json())
                .then(data => {
                    isInternetOnline = data.internet;
                    const statusText = document.getElementById('text-status');
                    
                    if (!isInternetOnline) {
                        statusText.innerHTML = '<i style="color:#ff4c4c;">🚫</i> <span style="color:#ff4c4c; font-weight:bold;">NO INTERNET</span>';
                        statusText.classList.add('offline-pulse');
                    } else {
                        statusText.classList.remove('offline-pulse');
                        if (isExpiredPHP) {
                            statusText.innerHTML = '<i style="color:#ff4c4c;">🚫</i> <span style="color:#ff4c4c;">No active session</span>';
                        } else {
                            statusText.innerHTML = '<i style="color:#10b981;">📶</i> Uplink Active';
                        }
                    }
                    updateDashboard(); 
                }).catch(e => {});
            setTimeout(checkServerInternet, 4000);
        }
        setTimeout(checkServerInternet, 1000);

        function triggerChatWidget() {
            let vcBtn = document.getElementById('vc-btn');
            if (vcBtn) {
                if (document.getElementById('vc-panel').style.display !== 'flex') { vcBtn.click(); }
                setTimeout(() => {
                    let msgBox = document.getElementById('vc-input-msg');
                    if (msgBox) {
                        msgBox.value = "Hi Sir RJ! I would like to extend/renew my monthly subscription! 🚀";
                        msgBox.focus();
                    }
                }, 300);
            }
        }

        function triggerSubmitLoader(e, form) {
            e.preventDefault();
            document.getElementById('m-loading').style.display = 'flex';
            setTimeout(() => form.submit(), 1500); 
        }

        setInterval(updateDashboard, 1000);
        updateDashboard(); 
    </script>
</body>
</html>
