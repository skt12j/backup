<?php
// portal/check_coin.php - OPENWRT RAM-DISK EDITION (Hardware Protector)
require_once '../core.php';

header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// 🔥 OPENWRT HARDWARE FIX: Read from RAM disk to match slot_api.php! 🔥
$buffer_file = '/tmp/coin_buffer.txt';

if (file_exists($buffer_file)) {
    $fp = fopen($buffer_file, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
        $raw_signal = fread($fp, filesize($buffer_file) ?: 1);
        $current_coin = (int)trim($raw_signal);
        
        if ($current_coin > 0) {
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, '0');
            fflush($fp);
            flock($fp, LOCK_UN);
            fclose($fp);
            
            echo json_encode([
                'status' => 'success',
                'coin' => $current_coin,
                'timestamp' => time(),
                'msg' => 'CURRENCY_ACCEPTED'
            ]);
            exit;
        }
        flock($fp, LOCK_UN);
    }
    if ($fp) { fclose($fp); }
}

echo json_encode([
    'status' => 'idle',
    'coin' => 0,
    'timestamp' => time()
]);
?>