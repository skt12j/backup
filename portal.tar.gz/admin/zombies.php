<?php
// admin/zombies.php - OPENWRT RAM-DISK EDITION
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); exit;
}

$message = '';
$sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
$current_time = time();

$pruned = false;
foreach ($sessions as $mac => $data) {
    $has_pending_coins = isset($data['pending_coins']) && $data['pending_coins'] > 0;
    if ($data['status'] !== 'paused' && $data['status'] !== 'inactive' && !$has_pending_coins && ($data['expires'] ?? 0) > 0 && ($current_time - $data['expires']) >= 7200) {
        unset($sessions[$mac]);
        $pruned = true;
    }
}
if ($pruned) pushToVault('sessions.json', json_encode($sessions));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mac'])) {
    $mac = $_POST['mac'];
    $action = $_POST['action'];
    $ip = $sessions[$mac]['ip'] ?? '0.0.0.0';

    if ($action === 'revive') {
        $val = (float)$_POST['val'];
        $tier = $_POST['tier'] ?? 'Regular';

        $sessions[$mac] = [ 
            'ip' => $ip, 
            'tier' => $tier, 
            'active_mode' => 'Time',
            'status' => 'active', 
            'time_left' => 0 
        ];

        $sessions[$mac]['expires'] = time() + ($val * 60);

        fw_allow($mac, $ip, $tier);
        pushToVault('sessions.json', json_encode($sessions));
        $message = "<div class='status-badge' style='color:var(--success); border-color:var(--success);'>✅ MAC [$mac] REVIVED</div>";
    } 
    elseif ($action === 'approve_recovery') {
        $coins = (int)($sessions[$mac]['pending_coins'] ?? 0);
        $target_tier = $_POST['tier'] ?? 'Regular';

        $rates_data = json_decode(pullFromVault('rates.json'), true) ?: [];
        $tier_rates = $rates_data['Time'][$target_tier] ?? []; 
        
        $val_added = 0; $remaining_coins = $coins;
        $available_denoms = array_keys($tier_rates); rsort($available_denoms, SORT_NUMERIC); 
        foreach ($available_denoms as $denom) {
            $denom_int = (int)$denom; if ($denom_int <= 0) continue;
            $count = floor($remaining_coins / $denom_int);
            if ($count > 0) { $val_added += ($count * (float)$tier_rates[$denom]); $remaining_coins -= ($count * $denom_int); }
        }

        if ($val_added > 0) {
            $sessions[$mac]['active_mode'] = 'Time';
            $sessions[$mac]['tier'] = $target_tier;
            $sessions[$mac]['status'] = 'active';

            $old_time = (($sessions[$mac]['expires'] ?? 0) > time()) ? ($sessions[$mac]['expires'] - time()) : (int)($sessions[$mac]['time_left'] ?? 0);
            $sessions[$mac]['expires'] = time() + ($val_added * 60) + $old_time;
            $sessions[$mac]['time_left'] = 0;

            unset($sessions[$mac]['pending_coins']);
            fw_allow($mac, $ip, $target_tier);
            
            $sales_raw = pullFromVault('sales.txt');
            $total_sales = is_numeric($sales_raw) ? (float)$sales_raw : 0.00;
            $total_sales += $coins;
            pushToVault('sales.txt', (string)$total_sales);
            
            $logs = json_decode(pullFromVault('logs.json'), true) ?: [];
            $logs[] = ['date' => date('Y-m-d H:i:s'), 'mac' => $mac, 'event' => 'MANUAL_RECOVERY', 'tier' => $target_tier, 'details' => "Recovered: ₱$coins | Added: $val_added Mins", 'revenue' => (float)$coins];
            pushToVault('logs.json', json_encode($logs));
            
            $message = "<div class='status-badge' style='color:var(--success); border-color:var(--success);'>✅ RECOVERY APPROVED. Time Stacked.</div>";
        }
        pushToVault('sessions.json', json_encode($sessions));
    }
    elseif ($action === 'reject_recovery') {
        unset($sessions[$mac]['pending_coins']);
        pushToVault('sessions.json', json_encode($sessions));
        $message = "<div class='status-badge' style='color:var(--danger); border-color:var(--danger);'>❌ RECOVERY REJECTED. Coins Cleared.</div>";
    }
    elseif ($action === 'delete') {
        unset($sessions[$mac]);
        pushToVault('sessions.json', json_encode($sessions));
        $message = "<div class='status-badge' style='color:var(--info); border-color:var(--info);'>🗑️ NODE PURGED.</div>";
    }
}

require_once 'header.php';
?>

<style>
    .table-container { max-height: 400px; overflow-y: auto; background: rgba(0,0,0,0.3); border-radius: 4px; border: 1px solid #333; }
    th { position: sticky; top: 0; background: #050a15; z-index: 10; border-bottom: 2px solid var(--danger); }
</style>

<div style="margin-bottom: 30px;">
    <h1 style="color: var(--danger); text-shadow: 0 0 10px var(--danger);">THE CRYPT <span id="sync-pulse" style="font-size:0.5em; color:var(--success);">●</span></h1>
    <p style="color: #888;">Manage frozen coins and dead nodes.</p>
</div>

<?php echo $message; ?>

<div class="card" style="border-color: var(--warning); margin-bottom: 30px;">
    <h3 style="color: var(--warning); display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 1.5rem;">⚠️</span> PENDING RECOVERIES (HELD COINS)
    </h3>
    <div class="table-container">
        <table>
            <thead>
                <tr><th>MAC ADDRESS</th><th>IP</th><th>HELD AMOUNT</th><th>RECOVERY ACTION</th></tr>
            </thead>
            <tbody id="ajax-pending">
                <tr><td colspan='4' style='text-align:center; color:#555; padding: 20px;'>SCANNING...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div class="card" style="border-color: var(--danger); margin-bottom: 30px;">
    <h3 style="color: var(--danger);">EXPIRED & LOBBY SESSIONS (ZOMBIES)</h3>
    <div class="table-container">
        <table>
            <thead>
                <tr><th>MAC ADDRESS</th><th>LAST IP</th><th>TIER</th><th>REVIVE ACTION</th></tr>
            </thead>
            <tbody id="ajax-zombies">
                <tr><td colspan='4' style='text-align:center; color:#555; padding: 20px;'>SCANNING...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<div class="card" style="border-color: #555;">
    <h3 style="color: #888;">SHADOW REALM (BANNED)</h3>
    <div class="table-container">
        <table>
            <thead><tr><th>MAC ADDRESS</th><th>DATE BANNED</th><th>REASON</th><th>ACTION</th></tr></thead>
            <tbody id="ajax-banned">
                <tr><td colspan='4' style='text-align:center; color:#555; padding: 20px;'>SCANNING...</td></tr>
            </tbody>
        </table>
    </div>
</div>

<script>
    function fetchLiveZombies() {
        if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'SELECT') return;

        fetch('api_core.php?action=zombies')
            .then(response => response.json())
            .then(data => {
                let pendingHtml = '';
                let zombieHtml = '';

                data.zombies.forEach(z => {
                    let pendingCoins = parseInt(z.pending_coins || 0);

                    if (pendingCoins > 0) {
                        pendingHtml += `<tr>
                            <td style='font-family: "Orbitron"; color: var(--warning);'>${z.mac}</td>
                            <td>${z.ip}</td>
                            <td style='color: var(--success); font-weight:bold; font-size: 1.2rem;'>₱${pendingCoins}</td>
                            <td>
                                <div style='display:flex; gap:8px; justify-content:center; align-items:center;'>
                                    <form method='POST' style='display:flex; gap:5px; margin:0;'>
                                        <input type='hidden' name='mac' value='${z.mac}'>
                                        <input type='hidden' name='action' value='approve_recovery'>
                                        <select name='tier' style='background:#111; border:1px solid var(--info); color:#fff; font-size:0.7rem;'>
                                            <option value='Regular'>REG</option><option value='Gaming'>VIP</option>
                                        </select>
                                        <button type='submit' class='btn btn-success' style='padding:4px 8px; font-size:0.7rem;'>APPROVE TIME</button>
                                    </form>
                                    <form method='POST' style='margin:0;' onsubmit="return confirm('Reject coins?');">
                                        <input type='hidden' name='mac' value='${z.mac}'><input type='hidden' name='action' value='reject_recovery'>
                                        <button type='submit' class='btn btn-warning' style='padding:4px 8px; font-size:0.7rem;'>REJECT</button>
                                    </form>
                                </div>
                            </td>
                        </tr>`;
                    } else {
                        zombieHtml += `<tr>
                            <td style='font-family: "Orbitron";'>${z.mac}</td>
                            <td>${z.ip}</td>
                            <td style='color: var(--info);'>${z.tier ? z.tier.toUpperCase() : 'UNKNOWN'}</td>
                            <td>
                                <div style='display:flex; gap:10px; justify-content:center;'>
                                    <form method='POST' style='display:flex; gap:5px; margin:0;'>
                                        <input type='hidden' name='mac' value='${z.mac}'><input type='hidden' name='action' value='revive'>
                                        <input type='number' name='val' value='60' style='width:70px; background:#000; border:1px solid var(--success); color:var(--success); text-align:center;' placeholder='Mins'>
                                        <select name='tier' style='background:#000; border:1px solid var(--success); color:#fff; font-size:0.7rem;'>
                                            <option value='Regular'>REG</option><option value='Gaming'>VIP</option>
                                        </select>
                                        <button type='submit' class='btn btn-success' style='padding:4px 8px; font-size:0.7rem;'>REVIVE</button>
                                    </form>
                                    <form method='POST' style='margin:0;' onsubmit="return confirm('Purge this node?');">
                                        <input type='hidden' name='mac' value='${z.mac}'><input type='hidden' name='action' value='delete'>
                                        <button type='submit' class='btn btn-danger' style='padding:4px 8px; font-size:0.7rem;'>DEL</button>
                                    </form>
                                </div>
                            </td>
                        </tr>`;
                    }
                });

                document.getElementById('ajax-pending').innerHTML = pendingHtml || "<tr><td colspan='4' style='text-align:center; color:#555; padding: 20px;'>NO PENDING RECOVERIES.</td></tr>";
                document.getElementById('ajax-zombies').innerHTML = zombieHtml || "<tr><td colspan='4' style='text-align:center; color:#555; padding: 20px;'>THE CRYPT IS EMPTY.</td></tr>";

                let bannedHtml = '';
                data.banned.forEach(b => {
                    bannedHtml += `<tr><td style='font-family: "Orbitron"; color: var(--danger);'>${b.mac}</td><td>${b.date}</td><td>${b.reason}</td><td><form method='POST' action='ban.php' style='margin:0;'><input type='hidden' name='mac' value='${b.mac}'><input type='hidden' name='action' value='pardon'><button type='submit' class='btn btn-success' style='padding:2px 8px; font-size:0.7rem;'>PARDON</button></form></td></tr>`;
                });
                document.getElementById('ajax-banned').innerHTML = bannedHtml || "<tr><td colspan='4' style='text-align:center; color:#555; padding: 20px;'>NO BANNED USERS.</td></tr>";

                let pulse = document.getElementById('sync-pulse');
                pulse.style.opacity = '1';
                setTimeout(() => pulse.style.opacity = '0.2', 500);
            })
            .catch(err => console.error("SYNC ERROR:", err));
    }

    fetchLiveZombies();
    setInterval(fetchLiveZombies, 3000);
</script>
</body></html>