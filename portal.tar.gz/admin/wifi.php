<?php
// admin/wifi.php - OPENWRT RAM-DISK EDITION (Advanced Wireless Commander)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); exit;
}

$message = '';
$wireless_config_file = '/etc/config/wireless';

// ==========================================
// 🔥 HANDLE FORM SUBMISSION & UCI RELOAD 🔥
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_wifi') {
    
    if (file_exists($wireless_config_file)) {
        // --- 2.4GHz RADIO (Device 0) ---
        shell_exec("uci set wireless.@wifi-device[0].channel='" . escapeshellarg($_POST['channel_2g'] ?? '1') . "'");
        shell_exec("uci set wireless.@wifi-device[0].txpower='" . escapeshellarg($_POST['txpower_2g'] ?? '100') . "'");

        // 2.4GHz MAIN (Iface 0)
        shell_exec("uci set wireless.@wifi-iface[0].ssid='" . escapeshellarg($_POST['main_2g_ssid']) . "'");
        if (!empty($_POST['main_2g_pass'])) {
            shell_exec("uci set wireless.@wifi-iface[0].key='" . escapeshellarg($_POST['main_2g_pass']) . "'");
            shell_exec("uci set wireless.@wifi-iface[0].encryption='psk2'");
        }
        shell_exec("uci set wireless.@wifi-iface[0].hidden='" . (isset($_POST['main_2g_hide']) ? '1' : '0') . "'");

        // 2.4GHz PISO (Iface 1)
        shell_exec("uci set wireless.@wifi-iface[1].ssid='" . escapeshellarg($_POST['piso_2g_ssid']) . "'");
        shell_exec("uci set wireless.@wifi-iface[1].hidden='" . (isset($_POST['piso_2g_hide']) ? '1' : '0') . "'");

        // --- 5GHz RADIO (Device 1) ---
        shell_exec("uci set wireless.@wifi-device[1].channel='" . escapeshellarg($_POST['channel_5g'] ?? '36') . "'");
        shell_exec("uci set wireless.@wifi-device[1].htmode='" . escapeshellarg($_POST['width_5g'] ?? 'HE80') . "'");
        shell_exec("uci set wireless.@wifi-device[1].txpower='" . escapeshellarg($_POST['txpower_5g'] ?? '100') . "'");

        // 5GHz MAIN (Iface 2)
        shell_exec("uci set wireless.@wifi-iface[2].ssid='" . escapeshellarg($_POST['main_5g_ssid']) . "'");
        if (!empty($_POST['main_5g_pass'])) {
            shell_exec("uci set wireless.@wifi-iface[2].key='" . escapeshellarg($_POST['main_5g_pass']) . "'");
            shell_exec("uci set wireless.@wifi-iface[2].encryption='psk2'");
        }
        shell_exec("uci set wireless.@wifi-iface[2].hidden='" . (isset($_POST['main_5g_hide']) ? '1' : '0') . "'");

        // 5GHz PISO (Iface 3)
        shell_exec("uci set wireless.@wifi-iface[3].ssid='" . escapeshellarg($_POST['piso_5g_ssid']) . "'");
        shell_exec("uci set wireless.@wifi-iface[3].hidden='" . (isset($_POST['piso_5g_hide']) ? '1' : '0') . "'");

        // Commit and apply changes safely in the background
        shell_exec("uci commit wireless && wifi reload > /dev/null 2>&1 &");

        $message = "<div style='background: rgba(16, 185, 129, 0.1); border-left: 4px solid var(--success); padding: 15px; margin-bottom: 25px; color: var(--success); font-family: \"Source Code Pro\"; font-weight: bold;'>> KERNEL UPDATED: Wireless configuration saved and radios are restarting. Please wait 10 seconds for SSIDs to reappear.</div>";
    } else {
        $message = "<div style='background: rgba(255, 76, 76, 0.1); border-left: 4px solid var(--danger); padding: 15px; margin-bottom: 25px; color: var(--danger); font-family: \"Source Code Pro\"; font-weight: bold;'>> ERROR: /etc/config/wireless missing.</div>";
    }
}

// ==========================================
// 📡 FETCH LIVE UCI SETTINGS 📡
// ==========================================
$uci_raw = shell_exec("uci show wireless 2>/dev/null");

function getUciVal($raw, $key, $default = '') {
    if (preg_match("/" . preg_quote($key, '/') . "='?(.*?)'?$/m", $raw, $matches)) return trim($matches[1]);
    return $default;
}

$c_ch2 = getUciVal($uci_raw, 'wireless.@wifi-device[0].channel', '1');
$c_tx2 = getUciVal($uci_raw, 'wireless.@wifi-device[0].txpower', '100');
$c_m2_ssid = getUciVal($uci_raw, 'wireless.@wifi-iface[0].ssid', 'NIMOS MAIN 2.4G');
$c_m2_hide = getUciVal($uci_raw, 'wireless.@wifi-iface[0].hidden', '0');
$c_p2_ssid = getUciVal($uci_raw, 'wireless.@wifi-iface[1].ssid', 'ANONIMOS PISO WIFI 2.4G');
$c_p2_hide = getUciVal($uci_raw, 'wireless.@wifi-iface[1].hidden', '0');

$c_ch5 = getUciVal($uci_raw, 'wireless.@wifi-device[1].channel', '36');
$c_ht5 = getUciVal($uci_raw, 'wireless.@wifi-device[1].htmode', 'HE80');
$c_tx5 = getUciVal($uci_raw, 'wireless.@wifi-device[1].txpower', '100');
$c_m5_ssid = getUciVal($uci_raw, 'wireless.@wifi-iface[2].ssid', 'NIMOS MAIN 5G');
$c_m5_hide = getUciVal($uci_raw, 'wireless.@wifi-iface[2].hidden', '0');
$c_p5_ssid = getUciVal($uci_raw, 'wireless.@wifi-iface[3].ssid', 'ANONIMOS PISO WIFI 5G');
$c_p5_hide = getUciVal($uci_raw, 'wireless.@wifi-iface[3].hidden', '0');

require_once 'header.php';
?>

<style>
    /* PREMIUM VAULT OS UI INJECTIONS */
    .wifi-card { background: rgba(10, 15, 25, 0.8); border: 1px solid #1a2a44; border-radius: 8px; padding: 25px; margin-bottom: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
    .wifi-card-2g { border-top: 4px solid var(--info); }
    .wifi-card-5g { border-top: 4px solid var(--vip); }
    
    .cyber-label { color: #8a8d98; font-family: 'Orbitron'; font-size: 0.75rem; letter-spacing: 1px; margin-bottom: 8px; display: block; }
    
    .cyber-input, .cyber-select { 
        width: 100%; background: rgba(0,0,0,0.6); color: #fff; border: 1px solid #2a3a54; padding: 12px 15px; 
        font-family: 'Rajdhani'; font-size: 1.1rem; font-weight: bold; border-radius: 4px; transition: all 0.3s; box-sizing: border-box; 
    }
    .cyber-input:focus, .cyber-select:focus { border-color: var(--info); box-shadow: 0 0 15px rgba(0,243,255,0.2); outline: none; }
    .wifi-card-5g .cyber-input:focus, .wifi-card-5g .cyber-select:focus { border-color: var(--vip); box-shadow: 0 0 15px rgba(176,38,255,0.2); }
    
    .sub-section { background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); padding: 20px; border-radius: 6px; margin-top: 20px; position: relative; }
    .sub-section::before { content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 3px; background: #334155; border-radius: 6px 0 0 6px; }
    .sub-section.br-lan::before { background: var(--success); }
    .sub-section.br-guest::before { background: var(--warning); }
    
    .sub-title { font-family: 'Source Code Pro'; font-size: 0.85rem; color: #fff; margin-top: 0; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }
    .badge { padding: 3px 8px; border-radius: 3px; font-size: 0.65rem; font-family: 'Orbitron'; font-weight: bold; background: rgba(255,255,255,0.1); }
    .badge-lan { background: rgba(16, 185, 129, 0.2); color: var(--success); border: 1px solid var(--success); }
    .badge-guest { background: rgba(245, 158, 11, 0.2); color: var(--warning); border: 1px solid var(--warning); }
    
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    @media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }
    
    /* Cyber Toggle Switch */
    .cyber-switch { position: relative; display: inline-block; width: 44px; height: 22px; }
    .cyber-switch input { opacity: 0; width: 0; height: 0; }
    .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #1a2a44; transition: .3s; border-radius: 22px; border: 1px solid #2a3a54; }
    .slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 3px; bottom: 3px; background-color: #8a8d98; transition: .3s; border-radius: 50%; }
    input:checked + .slider { background-color: rgba(0, 243, 255, 0.2); border-color: var(--info); box-shadow: inset 0 0 5px var(--info); }
    input:checked + .slider:before { transform: translateX(22px); background-color: var(--info); box-shadow: 0 0 10px var(--info); }
    
    .wifi-card-5g input:checked + .slider { background-color: rgba(176, 38, 255, 0.2); border-color: var(--vip); box-shadow: inset 0 0 5px var(--vip); }
    .wifi-card-5g input:checked + .slider:before { background-color: var(--vip); box-shadow: 0 0 10px var(--vip); }

    .toggle-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-top: 1px dashed rgba(255,255,255,0.05); margin-top: 15px; }
    
    .pass-wrapper { position: relative; }
    .pass-toggle { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); cursor: pointer; opacity: 0.5; transition: opacity 0.2s; font-size: 1.2rem; }
    .pass-toggle:hover { opacity: 1; }
</style>

<div style="margin-bottom: 30px;">
    <h1 style="color: #fff; text-shadow: 0 0 15px rgba(255,255,255,0.3); font-size: 2.2rem; margin-bottom: 5px;">
        <span style="color: var(--info);">📡 RADIO</span> COMMANDER
    </h1>
    <p style="color: #8a8d98; font-size: 1.05rem;">Advanced Hardware & SSID Configuration Engine</p>
</div> 

<?php echo $message; ?>

<form method="POST" id="wifi-form">
    <input type="hidden" name="action" value="save_wifi">

    <!-- ===================================== -->
    <!-- 2.4 GHZ RADIO CARD -->
    <!-- ===================================== -->
    <div class="wifi-card wifi-card-2g">
        <h2 style="color: var(--info); margin-top: 0; display: flex; align-items: center; gap: 10px; font-size: 1.4rem;">
            <i style="font-style: normal;">📶</i> 2.4 GHz BAND (Radio 0)
        </h2>
        
        <div class="form-grid" style="margin-bottom: 10px;">
            <div>
                <label class="cyber-label">OPERATING CHANNEL</label>
                <select name="channel_2g" class="cyber-select">
                    <option value="auto" <?php echo ($c_ch2 == 'auto') ? 'selected' : ''; ?>>Auto (Dynamic)</option>
                    <?php foreach([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] as $ch): ?>
                        <option value="<?php echo $ch; ?>" <?php echo ($c_ch2 == $ch) ? 'selected' : ''; ?>>Channel <?php echo $ch; ?> <?php echo in_array($ch, [1,6,11]) ? '(Optimal)' : ''; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="cyber-label">TRANSMIT POWER (TX)</label>
                <select name="txpower_2g" class="cyber-select">
                    <option value="100" <?php echo ($c_tx2 == '100') ? 'selected' : ''; ?>>100% (Maximum)</option>
                    <option value="75" <?php echo ($c_tx2 == '75') ? 'selected' : ''; ?>>75% (High)</option>
                    <option value="50" <?php echo ($c_tx2 == '50') ? 'selected' : ''; ?>>50% (Medium)</option>
                    <option value="25" <?php echo ($c_tx2 == '25') ? 'selected' : ''; ?>>25% (Low)</option>
                </select>
            </div>
        </div>

        <div class="sub-section br-lan">
            <h3 class="sub-title">PRIVATE NETWORK <span class="badge badge-lan">br-lan</span></h3>
            <div class="form-grid">
                <div>
                    <label class="cyber-label">SSID (NETWORK NAME)</label>
                    <input type="text" name="main_2g_ssid" value="<?php echo htmlspecialchars($c_m2_ssid); ?>" required class="cyber-input">
                </div>
                <div>
                    <label class="cyber-label">WPA2 PASSWORD</label>
                    <div class="pass-wrapper">
                        <input type="password" name="main_2g_pass" id="p1" placeholder="Leave blank to keep current" class="cyber-input">
                        <span class="pass-toggle" onclick="togglePass('p1', this)">👁️</span>
                    </div>
                </div>
            </div>
            <div class="toggle-row">
                <div>
                    <strong style="color: #fff; font-size: 0.9rem;">Hide Network (Stealth Mode)</strong><br>
                    <span style="color: #8a8d98; font-size: 0.8rem;">Prevents SSID from broadcasting.</span>
                </div>
                <label class="cyber-switch">
                    <input type="checkbox" name="main_2g_hide" <?php echo ($c_m2_hide == '1') ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
            </div>
        </div>

        <div class="sub-section br-guest">
            <h3 class="sub-title">PISO WIFI HOTSPOT <span class="badge badge-guest">br-guest</span></h3>
            <div>
                <label class="cyber-label">SSID (NETWORK NAME) - OPEN NETWORK</label>
                <input type="text" name="piso_2g_ssid" value="<?php echo htmlspecialchars($c_p2_ssid); ?>" required class="cyber-input" style="border-color: var(--warning);">
            </div>
            <div class="toggle-row">
                <div>
                    <strong style="color: #fff; font-size: 0.9rem;">Hide Hotspot</strong>
                </div>
                <label class="cyber-switch">
                    <input type="checkbox" name="piso_2g_hide" <?php echo ($c_p2_hide == '1') ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
            </div>
        </div>
    </div>

    <!-- ===================================== -->
    <!-- 5 GHZ RADIO CARD -->
    <!-- ===================================== -->
    <div class="wifi-card wifi-card-5g">
        <h2 style="color: var(--vip); margin-top: 0; display: flex; align-items: center; gap: 10px; font-size: 1.4rem;">
            <i style="font-style: normal;">🚀</i> 5 GHz BAND (Radio 1)
        </h2>
        
        <div class="form-grid" style="margin-bottom: 20px;">
            <div>
                <label class="cyber-label">OPERATING CHANNEL</label>
                <select name="channel_5g" class="cyber-select">
                    <option value="auto" <?php echo ($c_ch5 == 'auto') ? 'selected' : ''; ?>>Auto (Dynamic)</option>
                    <?php foreach([36, 40, 44, 48, 149, 153, 157, 161] as $ch): ?>
                        <option value="<?php echo $ch; ?>" <?php echo ($c_ch5 == $ch) ? 'selected' : ''; ?>>Channel <?php echo $ch; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="cyber-label">CHANNEL WIDTH (Wi-Fi 6 AX)</label>
                <select name="width_5g" class="cyber-select">
                    <option value="HE20" <?php echo strpos($c_ht5, '20') !== false ? 'selected' : ''; ?>>20 MHz (Longest Range)</option>
                    <option value="HE40" <?php echo strpos($c_ht5, '40') !== false ? 'selected' : ''; ?>>40 MHz (Balanced)</option>
                    <option value="HE80" <?php echo strpos($c_ht5, '80') !== false ? 'selected' : ''; ?>>80 MHz (Max Speed / Recommended)</option>
                </select>
            </div>
            <div>
                <label class="cyber-label">TRANSMIT POWER (TX)</label>
                <select name="txpower_5g" class="cyber-select">
                    <option value="100" <?php echo ($c_tx5 == '100') ? 'selected' : ''; ?>>100% (Maximum)</option>
                    <option value="75" <?php echo ($c_tx5 == '75') ? 'selected' : ''; ?>>75% (High)</option>
                    <option value="50" <?php echo ($c_tx5 == '50') ? 'selected' : ''; ?>>50% (Medium)</option>
                </select>
            </div>
        </div>

        <div class="sub-section br-lan">
            <h3 class="sub-title">PRIVATE NETWORK <span class="badge badge-lan">br-lan</span></h3>
            <div class="form-grid">
                <div>
                    <label class="cyber-label">SSID (NETWORK NAME)</label>
                    <input type="text" name="main_5g_ssid" value="<?php echo htmlspecialchars($c_m5_ssid); ?>" required class="cyber-input">
                </div>
                <div>
                    <label class="cyber-label">WPA2 PASSWORD</label>
                    <div class="pass-wrapper">
                        <input type="password" name="main_5g_pass" id="p2" placeholder="Leave blank to keep current" class="cyber-input">
                        <span class="pass-toggle" onclick="togglePass('p2', this)">👁️</span>
                    </div>
                </div>
            </div>
            <div class="toggle-row">
                <div>
                    <strong style="color: #fff; font-size: 0.9rem;">Hide Network (Stealth Mode)</strong>
                </div>
                <label class="cyber-switch">
                    <input type="checkbox" name="main_5g_hide" <?php echo ($c_m5_hide == '1') ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
            </div>
        </div>

        <div class="sub-section br-guest">
            <h3 class="sub-title">PISO WIFI HOTSPOT <span class="badge badge-guest">br-guest</span></h3>
            <div>
                <label class="cyber-label">SSID (NETWORK NAME) - OPEN NETWORK</label>
                <input type="text" name="piso_5g_ssid" value="<?php echo htmlspecialchars($c_p5_ssid); ?>" required class="cyber-input" style="border-color: var(--warning);">
            </div>
            <div class="toggle-row">
                <div>
                    <strong style="color: #fff; font-size: 0.9rem;">Hide Hotspot</strong>
                </div>
                <label class="cyber-switch">
                    <input type="checkbox" name="piso_5g_hide" <?php echo ($c_p5_hide == '1') ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
            </div>
        </div>
    </div>

    <button type="button" onclick="confirmSave()" class="btn btn-success" style="width: 100%; font-size: 1.2rem; padding: 18px; box-shadow: 0 0 20px rgba(16, 185, 129, 0.4); text-transform: uppercase; font-weight: 900; letter-spacing: 2px;">
        💾 INITIALIZE KERNEL OVERRIDE
    </button>
</form>

<script>
    function togglePass(id, icon) {
        var el = document.getElementById(id);
        if (el.type === "password") {
            el.type = "text";
            icon.innerText = "🙈";
        } else {
            el.type = "password";
            icon.innerText = "👁️";
        }
    }

    function confirmSave() {
        if(confirm("⚠️ CRITICAL OVERRIDE ⚠️\n\nSaving these settings will reboot the physical Wi-Fi radios. \nYour connection will drop for about 10-15 seconds.\n\nAre you sure you want to proceed?")) {
            document.getElementById('wifi-form').submit();
        }
    }
</script>

</body>
</html>
