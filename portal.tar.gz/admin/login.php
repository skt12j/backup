<?php
// admin/login.php - OPENWRT RAM-DISK EDITION

// 1. ABSOLUTE FIRST LINE: Load core to access RAM disk sessions
require_once '../core.php';

// 2. 🛡️ THE BOUNCER: Kick 10.0.0.x captive portal users out!
$client_ip = $_SERVER['REMOTE_ADDR'];
if (strpos($client_ip, '10.0.0.') === 0) {
    header("Location: ../portal/");
    exit;
}

// 3. LOOP BREAKER: If already logged in, go straight to the dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: index.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass = $_POST['password'] ?? '';
    
    // Default Access Code
    if ($pass === '10212002') { 
        $_SESSION['admin_logged_in'] = true;
        
        // 🔥 FORCE SAVE FIX: Ensure OpenWrt writes the session to the RAM disk before redirecting!
        session_write_close(); 
        
        header("Location: index.php");
        exit;
    } else {
        $error = "INVALID ACCESS CODE";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VAULT OS - Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    <style>
        body { background: #050a15; color: #00f3ff; font-family: 'Rajdhani', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { border: 1px solid #00f3ff; padding: 40px; background: rgba(0, 243, 255, 0.05); box-shadow: 0 0 15px rgba(0, 243, 255, 0.2); text-align: center; border-radius: 5px; width: 100%; max-width: 350px; }
        h2 { font-family: 'Orbitron', sans-serif; letter-spacing: 2px; text-shadow: 0 0 10px #00f3ff; margin-bottom: 30px; }
        input { width: 100%; padding: 12px; margin-bottom: 20px; background: #000; border: 1px solid #00f3ff; color: #00f3ff; font-family: 'Orbitron'; text-align: center; box-sizing: border-box; font-size: 1.1rem; }
        input:focus { outline: none; box-shadow: 0 0 10px #00f3ff; }
        button { width: 100%; padding: 12px; background: transparent; border: 1px solid #00f3ff; color: #00f3ff; font-family: 'Orbitron'; cursor: pointer; transition: 0.3s; font-size: 1.1rem; font-weight: bold; }
        button:hover { background: #00f3ff; color: #050a15; box-shadow: 0 0 15px #00f3ff; }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>VAULT OS</h2>
        <p style="color: #888; font-size: 0.9rem; margin-top: -20px; margin-bottom: 30px;">ADMIN PROTOCOL</p>
        <form method="POST">
            <input type="password" name="password" placeholder="ENTER ACCESS CODE" required>
            <button type="submit">AUTHENTICATE</button>
        </form>
        <p style="color: #ff4c4c; font-weight: bold; margin-top: 20px; text-shadow: 0 0 5px #ff4c4c;"><?php echo $error; ?></p>
    </div>
</body>
</html>