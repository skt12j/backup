<?php
// admin/ban.php - OPENWRT RAM-DISK EDITION
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    die("UNAUTHORIZED ACCESS.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['mac'])) {
    $action = $_POST['action'];
    $mac = strtolower(trim($_POST['mac']));
    
    $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
    $blocked = json_decode(pullFromVault('blocked.json'), true) ?: [];

    $ip = $sessions[$mac]['ip'] ?? '';

    if ($action === 'ban') {
        $reason = isset($_POST['reason']) ? $_POST['reason'] : "Admin Perma-Ban";
        
        $blocked[strtoupper($mac)] = [
            'date_banned' => date('Y-m-d H:i:s'),
            'reason' => $reason
        ];
        
        if (isset($sessions[$mac])) { unset($sessions[$mac]); }
        
        pushToVault('blocked.json', json_encode($blocked));
        pushToVault('sessions.json', json_encode($sessions));
        
        fw_ban($mac, $ip);
    }
    
    elseif ($action === 'pardon') {
        if (isset($blocked[strtoupper($mac)])) { unset($blocked[strtoupper($mac)]); }
        pushToVault('blocked.json', json_encode($blocked));
        
        fw_unban($mac);
    }
}

$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
header("Location: $referer");
exit;
?>