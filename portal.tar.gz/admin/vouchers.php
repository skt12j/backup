<?php
// admin/vouchers.php - OPENWRT RAM-DISK EDITION (Time-Only Edition)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$vouchers = json_decode(pullFromVault('vouchers.json'), true) ?: [];
$message = '';

// ⚡ PROCESS COMMANDS BEFORE UI LOADS
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    if ($_POST['action'] === 'generate') {
        $qty = (int)$_POST['qty'];
        $tier = $_POST['tier'];
        $price = (float)$_POST['price'];
        $value = (float)($_POST['value'] ?? 0); // Strictly Minutes for OpenWrt

        if ($qty > 0 && $value > 0) {
            $generated_count = 0;
            for ($i = 0; $i < $qty; $i++) {
                $random_string = substr(str_shuffle("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 6);
                $code = "RJ-" . $random_string;
                
                if (!isset($vouchers[$code])) {
                    $vouchers[$code] = [
                        'mode' => 'Time', 
                        'value' => $value, 
                        'tier' => $tier, 
                        'price' => $price,
                        'status' => 'unused', 
                        'created_date' => date('Y-m-d H:i:s'),
                        'used_by' => null, 
                        'used_date' => null,
                        'creator_mac' => 'ADMIN' 
                    ];
                    $generated_count++;
                }
            }
            pushToVault('vouchers.json', json_encode($vouchers));
            header("Location: vouchers.php?minted=$generated_count");
            exit; 
        }
    } 
    elseif ($_POST['action'] === 'delete' && isset($_POST['code'])) {
        unset($vouchers[$_POST['code']]);
        pushToVault('vouchers.json', json_encode($vouchers));
        $message = "<div style='color: var(--danger); margin-bottom: 20px; font-weight: bold;'>VOUCHER PURGED.</div>";
    }
    elseif ($_POST['action'] === 'clear_used') {
        foreach ($vouchers as $code => $data) {
            if ($data['status'] === 'used') unset($vouchers[$code]);
        }
        pushToVault('vouchers.json', json_encode($vouchers));
        $message = "<div style='color: var(--info); margin-bottom: 20px; font-weight: bold;'>ALL USED VOUCHERS CLEARED.</div>";
    }
}

if (isset($_GET['minted'])) {
    $count = (int)$_GET['minted'];
    $message = "<div style='color: var(--success); margin-bottom: 20px; font-weight: bold;'>SUCCESS: $count VOUCHERS MINTED.</div>";
}

require_once 'header.php'; 
?>

<style>
    /* 🖨️ THE PRINT MAGIC */
    .print-only { display: none; }
    
    .table-container {
        max-height: 400px;
        overflow-y: auto;
        overflow-x: auto;
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 4px;
        background: rgba(0,0,0,0.5);
    }
    
    .table-container th {
        position: sticky; top: 0; background: #0a0f18; z-index: 10; box-shadow: 0 2px 5px rgba(0,0,0,0.5);
    }
    
    @media print {
        @page { size: portrait; margin: 5mm; }
        body * { visibility: hidden; }
        .dashboard-ui { display: none !important; }
        body { background: #fff !important; margin: 0; padding: 0; }
        .print-only, .print-only * { visibility: visible; }
        .print-only { display: block !important; position: absolute; left: 0; top: 0; width: 100%; }
        * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; box-sizing: border-box !important; }
        .voucher-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; width: 100%; padding: 10px; }
        .voucher-ticket { border: 2px dashed #333; background: #fff; padding: 0; text-align: center; font-family: 'Arial', sans-serif; page-break-inside: avoid; position: relative; width: 100%; overflow: hidden; }
        .vt-header { background: #00f3ff; color: #000; font-family: 'Orbitron', sans-serif; font-weight: 900; padding: 6px; font-size: 12px; text-transform: uppercase; border-bottom: 2px solid #000; letter-spacing: 1px; }
        .vt-tier-gaming .vt-header { background: #b026ff; color: #fff; }
        .vt-body { padding: 10px; }
        .vt-code-box { border: 2px solid #000; padding: 6px; margin: 8px 0; background: #f0f0f0; box-shadow: 3px 3px 0px #000; }
        .vt-code { font-size: 18px; font-weight: bold; font-family: 'Courier New', monospace; letter-spacing: 1px; }
        .vt-details { font-size: 11px; font-weight: bold; margin-bottom: 8px; color: #222; }
        .vt-instructions { font-size: 9px; text-align: left; line-height: 1.4; border-top: 1px dotted #888; padding-top: 8px; font-family: 'Courier New', monospace; }
    }
</style>

<div class="dashboard-ui">
    <div style="margin-bottom: 30px;">
        <h1 style="color: var(--vip); text-shadow: 0 0 10px var(--vip);">VOUCHER MANAGEMENT <span id="sync-pulse" style="font-size:0.5em; color:var(--success);">●</span></h1>
        <p style="color: #888;">Generate access codes, print cards, and monitor consumption.</p>
    </div>

    <?php echo $message; ?>

    <div class="card" style="margin-bottom: 30px; border-color: var(--vip);">
        <h3 style="color: var(--vip);">MINT NEW VOUCHERS (ADMIN STOCK)</h3>
        <form method="POST" style="display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end;">
            <input type="hidden" name="action" value="generate">
            
            <div style="flex: 1; min-width: 120px;">
                <label style="color: var(--info); font-size: 0.9rem; margin-bottom: 5px; display: block;">QUANTITY:</label>
                <input type="number" name="qty" min="1" max="100" value="1" required style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
            </div>
            
            <div style="flex: 1; min-width: 150px;">
                <label id="val-label" style="color: var(--info); font-size: 0.9rem; margin-bottom: 5px; display: block;">MINUTES:</label>
                <input type="number" name="value" min="1" required style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
            </div>
            
            <div style="flex: 1; min-width: 120px;">
                <label style="color: var(--info); font-size: 0.9rem; margin-bottom: 5px; display: block;">PRICE (₱):</label>
                <input type="number" name="price" step="0.01" min="0" required style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff;">
            </div>

            <div style="flex: 1; min-width: 150px;">
                <label style="color: var(--info); font-size: 0.9rem; margin-bottom: 5px; display: block;">TIER:</label>
                <select name="tier" style="width: 100%; padding: 10px; background: #000; border: 1px solid var(--info); color: #fff; font-family: 'Rajdhani';">
                    <option value="Regular">Regular</option>
                    <option value="Gaming">VIP Gaming</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success" style="padding: 10px 20px; height: 42px;">MINT BATCH</button>
        </form>
    </div>

    <div class="card" style="margin-bottom: 30px; border-color: var(--success);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; flex-wrap: wrap; gap: 10px;">
            <h3 id="admin-count" style="color: var(--success); margin: 0;">MINTED BY ADMIN (0)</h3>
            <button onclick="window.print()" class="btn" style="margin: 0; border-color: #fff; color: #000; background: #fff; font-weight: bold; padding: 8px 15px;">
                🖨️ PRINT ADMIN VOUCHERS
            </button>
        </div>
        <p style="font-size: 0.8rem; color: #888; margin-top: -10px; margin-bottom: 15px;">These are ready to be printed and sold manually.</p>

        <div class="table-container">
            <table style="width: 100%; min-width: 600px;">
                <thead>
                    <tr>
                        <th>CODE</th>
                        <th>TIER</th>
                        <th>TIME VALUE</th>
                        <th>PRICE</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody id="admin-tbody">
                    <tr><td colspan='5' style='text-align: center; color: #555; padding: 20px;'>SCANNING VAULT...</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card" style="margin-bottom: 30px; border-color: var(--info);">
        <div style="margin-bottom: 15px;">
            <h3 id="user-count" style="color: var(--info); margin: 0;">BOUGHT BY USERS (0)</h3>
            <p style="font-size: 0.8rem; color: #888; margin-top: 5px;">These were generated directly from the Coin Slot.</p>
        </div>

        <div class="table-container">
            <table style="width: 100%; min-width: 600px;">
                <thead>
                    <tr>
                        <th>CODE</th>
                        <th>TIER</th>
                        <th>TIME VALUE</th>
                        <th>BOUGHT BY (MAC)</th>
                        <th>PRICE</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody id="user-tbody">
                    <tr><td colspan='6' style='text-align: center; color: #555; padding: 20px;'>SCANNING VAULT...</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card" style="border-color: #444;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h3 id="used-count" style="color: #888; margin: 0;">CONSUMED VOUCHERS (0)</h3>
            <form method="POST" onsubmit="return confirm('Clear all consumed vouchers to free up RAM?');" style="margin: 0;">
                <input type="hidden" name="action" value="clear_used">
                <button type="submit" class="btn" style="border-color: var(--danger); color: var(--danger); padding: 5px 10px; font-size: 0.8rem;">🗑️ CLEAR USED</button>
            </form>
        </div>

        <div class="table-container" style="opacity: 0.7;">
            <table style="width: 100%; min-width: 600px;">
                <thead>
                    <tr>
                        <th style="color:#666;">CODE</th>
                        <th style="color:#666;">TIME VALUE</th>
                        <th style="color:#666;">REDEEMED BY</th>
                        <th style="color:#666;">REDEEMED DATE</th>
                    </tr>
                </thead>
                <tbody id="used-tbody">
                    <tr><td colspan='4' style='text-align: center; color: #555; padding: 20px;'>SCANNING VAULT...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div> 

<div class="print-only">
    <div class="voucher-grid" id="print-grid"></div>
</div>

<script>
    function fetchLiveVouchers() {
        if (document.activeElement.tagName === 'INPUT') return;

        fetch('api_core.php?action=vouchers')
            .then(response => response.json())
            .then(data => {
                
                const formatValue = (v) => `${parseFloat(v.value || 0)} Mins`;
                
                // 1. ADMIN VOUCHERS & PRINT GRID
                document.getElementById('admin-count').innerText = `MINTED BY ADMIN (${data.admin.length})`;
                let adminHtml = '';
                let printHtml = '';
                if(data.admin.length === 0) {
                    adminHtml = "<tr><td colspan='5' style='text-align: center; color: #555;'>NO PRINTABLE VOUCHERS.</td></tr>";
                } else {
                    data.admin.forEach(v => {
                        let tierColor = v.tier === 'Gaming' ? 'var(--vip)' : 'var(--info)';
                        let displayVal = formatValue(v);
                        
                        adminHtml += `<tr>
                            <td style='font-family: "Orbitron", sans-serif; font-size: 1.1rem; color: #fff;'>${v.code}</td>
                            <td style='color: ${tierColor}; font-weight:bold;'>${v.tier}</td>
                            <td style='color: var(--success);'><strong>${displayVal}</strong></td>
                            <td style='color: var(--success); font-weight:bold;'>₱${v.price}</td>
                            <td>
                                <form method='POST' style='margin: 0;' onsubmit="return confirm('Delete this voucher forever?');">
                                    <input type='hidden' name='action' value='delete'>
                                    <input type='hidden' name='code' value='${v.code}'>
                                    <button type='submit' class='btn btn-danger' style='padding: 4px 10px; font-size: 0.8rem;'>🗑️ X</button>
                                </form>
                            </td>
                        </tr>`;

                        let printClass = v.tier === 'Gaming' ? 'vt-tier-gaming' : '';
                        printHtml += `<div class="voucher-ticket ${printClass}">
                            <div class="vt-header">ANONIMO'S VAULT OS</div>
                            <div class="vt-body">
                                <div class="vt-details">TIER: ${v.tier.toUpperCase()}</div>
                                <div class="vt-code-box">
                                    <div class="vt-code">${v.code}</div>
                                </div>
                                <div class="vt-details">
                                    TIME: ${displayVal} <span style="color: #888; margin-left: 5px;">// ₱${v.price}</span>
                                </div>
                                <div class="vt-instructions">
                                    <strong>> INITIALIZE UPLINK:</strong><br>
                                    [1] Connect to 'ANONIMO'S PiSo WiFi'<br>
                                    [2] Wait for Vault OS Terminal to load.<br>
                                    [3] Select 'REDEEM KEYCODE'.<br>
                                    [4] Input your Access Key above.<br>
                                    <strong>[5] Type 10.0.0.1 in browser to view Status.</strong>
                                </div>
                            </div>
                        </div>`;
                    });
                }
                document.getElementById('admin-tbody').innerHTML = adminHtml;
                document.getElementById('print-grid').innerHTML = printHtml;

                // 2. USER VOUCHERS
                document.getElementById('user-count').innerText = `BOUGHT BY USERS (${data.user.length})`;
                let userHtml = '';
                if(data.user.length === 0) {
                    userHtml = "<tr><td colspan='6' style='text-align: center; color: #555;'>NO UNREDEEMED USER VOUCHERS.</td></tr>";
                } else {
                    data.user.forEach(v => {
                        let tierColor = v.tier === 'Gaming' ? 'var(--vip)' : 'var(--info)';
                        let displayVal = formatValue(v);

                        userHtml += `<tr>
                            <td style='font-family: "Orbitron", sans-serif; font-size: 1.1rem; color: #fff;'>${v.code}</td>
                            <td style='color: ${tierColor}; font-weight:bold;'>${v.tier}</td>
                            <td style='color: var(--success);'><strong>${displayVal}</strong></td>
                            <td style='font-family: monospace; color: #aaa; font-size:0.8rem;'>${v.creator_mac}</td>
                            <td style='color: var(--success); font-weight:bold;'>₱${v.price}</td>
                            <td>
                                <form method='POST' style='margin: 0;' onsubmit="return confirm('Delete this voucher forever?');">
                                    <input type='hidden' name='action' value='delete'>
                                    <input type='hidden' name='code' value='${v.code}'>
                                    <button type='submit' class='btn btn-danger' style='padding: 4px 10px; font-size: 0.8rem;'>🗑️ X</button>
                                </form>
                            </td>
                        </tr>`;
                    });
                }
                document.getElementById('user-tbody').innerHTML = userHtml;

                // 3. USED VOUCHERS
                document.getElementById('used-count').innerText = `CONSUMED VOUCHERS (${data.used.length})`;
                let usedHtml = '';
                if(data.used.length === 0) {
                    usedHtml = "<tr><td colspan='4' style='text-align: center; color: #555;'>LEDGER IS CLEAN.</td></tr>";
                } else {
                    data.used.forEach(v => {
                        let displayVal = formatValue(v);

                        usedHtml += `<tr>
                            <td style='color: #888; text-decoration: line-through; font-family:"Orbitron";'>${v.code}</td>
                            <td style='color: #aaa;'>${displayVal}</td>
                            <td style='font-family: monospace; color: #aaa; font-size:0.8rem;'>${v.used_by}</td>
                            <td style='color: #666; font-size:0.8rem;'>${v.used_date}</td>
                        </tr>`;
                    });
                }
                document.getElementById('used-tbody').innerHTML = usedHtml;

                let pulse = document.getElementById('sync-pulse');
                pulse.style.opacity = '1';
                setTimeout(() => pulse.style.opacity = '0.2', 500);

            }).catch(err => console.error("SYNC ERROR:", err));
    }

    fetchLiveVouchers();
    setInterval(fetchLiveVouchers, 3000); 
</script>
</body></html>