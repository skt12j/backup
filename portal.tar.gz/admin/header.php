<?php
// admin/header.php - Security Check & Cyberpunk UI Shell (OpenWrt Edition)

// 1. ABSOLUTE FIRST LINE: Load core
require_once '../core.php';

// 2. SECURITY BOUNCER: Keep public captive portal users out!
$client_ip = $_SERVER['REMOTE_ADDR'];
if (strpos($client_ip, '10.0.0.') === 0) {
    header("Location: ../portal/");
    exit;
}

// 3. STRICT ADMIN SECURITY PROTOCOL
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Get current page name for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>
<link rel="icon" type="image/png" href="../assets/logo.png">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VAULT OS - Admin Interface</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #050a15;
            --sidebar-bg: #03060c;
            --info: #00f3ff;
            --vip: #b026ff;
            --success: #10b981;
            --danger: #ff4c4c;
        }
        
        body { background-color: var(--bg-color); color: var(--info); font-family: 'Rajdhani', sans-serif; margin: 0; display: flex; min-height: 100vh; }
        h1, h2, h3, h4 { font-family: 'Orbitron', sans-serif; text-transform: uppercase; margin-top: 0; }
        
        /* Sidebar Styling */
        .sidebar { width: 250px; background-color: var(--sidebar-bg); border-right: 1px solid var(--info); box-shadow: 2px 0 15px rgba(0, 243, 255, 0.1); padding: 20px 0; display: flex; flex-direction: column; }
        .brand { text-align: center; padding: 0 20px 20px 20px; border-bottom: 1px solid rgba(0, 243, 255, 0.3); margin-bottom: 20px; }
        .brand h2 { color: var(--success); text-shadow: 0 0 10px var(--success); font-size: 1.5rem; margin-bottom: 5px; }
        .brand span { font-size: 0.9rem; color: #888; }
        
        .nav-link { display: block; padding: 15px 25px; color: var(--info); text-decoration: none; font-family: 'Orbitron', sans-serif; font-size: 1.1rem; transition: all 0.3s; border-left: 4px solid transparent; }
        .nav-link:hover { background: rgba(0, 243, 255, 0.1); border-left-color: var(--info); text-shadow: 0 0 8px var(--info); }
        .nav-link.active { background: rgba(0, 243, 255, 0.15); border-left-color: var(--info); color: #fff; text-shadow: 0 0 10px var(--info); }
        .nav-link.danger:hover { background: rgba(255, 76, 76, 0.1); border-left-color: var(--danger); color: var(--danger); text-shadow: 0 0 8px var(--danger); }
        
        /* Main Content Area */
        .main-content { flex-grow: 1; padding: 30px; overflow-y: auto; }

        /* Reusable Admin Components */
        .card { background: rgba(0, 243, 255, 0.05); border: 1px solid var(--info); padding: 20px; box-shadow: 0 0 15px rgba(0, 243, 255, 0.1); border-radius: 5px; }
        .btn { background: transparent; color: var(--info); border: 1px solid var(--info); padding: 10px 20px; font-family: 'Orbitron', sans-serif; cursor: pointer; text-transform: uppercase; transition: all 0.3s ease; }
        .btn:hover { background: var(--info); color: var(--bg-color); box-shadow: 0 0 10px var(--info); }
        .btn-success { border-color: var(--success); color: var(--success); }
        .btn-success:hover { background: var(--success); color: var(--bg-color); box-shadow: 0 0 10px var(--success); }
        .btn-danger { border-color: var(--danger); color: var(--danger); }
        .btn-danger:hover { background: var(--danger); color: var(--bg-color); box-shadow: 0 0 10px var(--danger); }
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid rgba(0, 243, 255, 0.2); }
        th { font-family: 'Orbitron', sans-serif; color: var(--vip); }
    </style>
    
    <script>
        // --- 🛡️ AUTO-LOGOUT SECURITY PROTOCOL ---
        // 15 Minutes = 900 seconds
        let idleTime = 0;
        const maxIdleTime = 900; 
        
        function resetIdleTime() {
            idleTime = 0;
        }

        setInterval(function () {
            idleTime++;
            if (idleTime >= maxIdleTime) {
                window.location.href = 'logout.php';
            }
        }, 1000);

        window.onload = resetIdleTime;
        document.onmousemove = resetIdleTime;
        document.onkeypress = resetIdleTime;
        document.onclick = resetIdleTime;
        document.onscroll = resetIdleTime;
    </script>
</head>
<body>

    <div class="sidebar">
        <div class="brand">
            <h2>VAULT OS</h2>
            <span>ANONIMO'S PISO WIFI</span>
        </div>
        
        <a href="index.php" class="nav-link <?php echo $current_page == 'index.php' ? 'active' : ''; ?>">Dashboard</a>
        <a href="subscribers.php" class="nav-link <?php echo $current_page == 'subscribers.php' ? 'active' : ''; ?>">SUBSCRIPTION</a>
        <a href="wifi.php" class="nav-link">📶 WiFi Config</a>
        <a href="bandwidth.php" class="nav-link <?php echo $current_page == 'bandwidth.php' ? 'active' : ''; ?>">Bandwidth Control</a>
        <a href="network.php" class="nav-link <?php echo $current_page == 'network.php' ? 'active' : ''; ?>">Network Manager</a>
        <a href="users.php" class="nav-link <?php echo $current_page == 'users.php' ? 'active' : ''; ?>">Active Users</a>
        <a href="vouchers.php" class="nav-link <?php echo $current_page == 'vouchers.php' ? 'active' : ''; ?>">Vouchers</a>
        <a href="rates.php" class="nav-link <?php echo $current_page == 'rates.php' ? 'active' : ''; ?>">Rates Config</a>
        <a href="zombies.php" class="nav-link <?php echo $current_page == 'zombies.php' ? 'active' : ''; ?>">Zombies (Expired)</a>
        <a href="logs.php" class="nav-link <?php echo $current_page == 'logs.php' ? 'active' : ''; ?>">System Logs</a>
        
        <div style="flex-grow: 1;"></div>
        <a href="logout.php" class="nav-link danger">Terminate Session</a>
    </div>

    <div class="main-content">
