<?php
// admin/network.php - OPENWRT RAM-DISK EDITION (Network & DNS Manager)
require_once '../core.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php"); exit;
}

$message = '';
$dns_file = DB_DIR . 'dns.json';
$whitelist_file = DB_DIR . 'whitelist.json';

// Create defaults if missing
if (!file_exists($dns_file)) { pushToVault('dns.json', json_encode(["adblock" => "off"])); }
if (!file_exists($whitelist_file)) { pushToVault('whitelist.json', json_encode([])); }

$whitelist = json_decode(pullFromVault('whitelist.json'), true) ?: [];
$router_ip = $_SERVER['SERVER_ADDR'] ?? '10.0.0.1';

// ==========================================
// 🔥 ACTION HANDLERS 🔥
// ==========================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // 1. KICK / RELEASE DEVICE (INSTANT SEVER)
    if ($action === 'kick_device') {
        $mac_to_kick = strtolower(trim($_POST['mac']));
        $sessions = json_decode(pullFromVault('sessions.json'), true) ?: [];
        
        if (isset($sessions[$mac_to_kick])) {
            $ip_to_kick = $sessions[$mac_to_kick]['ip'] ?? '';
            
            $sessions[$mac_to_kick]['time_left'] = 0;
            $sessions[$mac_to_kick]['expires'] = time() - 100;
            $sessions[$mac_to_kick]['status'] = 'expired';
            pushToVault('sessions.json', json_encode($sessions));
            
            fw_drop($mac_to_kick, $ip_to_kick);
            $message = "<div style='color: var(--success); margin-bottom: 20px; font-weight: bold;'>SUCCESS: Target $mac_to_kick has been neutralized and kicked.</div>";
        } else {
            $message = "<div style='color: var(--warning); margin-bottom: 20px; font-weight: bold;'>WARNING: Device had no active paid session to clear.</div>";
        }
    }
    
    // 2. GRANT PERMA-WHITELIST
    elseif ($action === 'whitelist_device') {
        $raw_mac = strtolower(trim($_POST['mac']));
        fw_allow($raw_mac, '', 'Regular');
        $whitelist[$raw_mac] = true;
        pushToVault('whitelist.json', json_encode($whitelist));
        $message = "<div style='color: #b026ff; margin-bottom: 20px; font-weight: bold;'>⚡ GOD MODE GRANTED: $raw_mac now has permanent, unrestricted access.</div>";
    }
    
    // 3. REVOKE PERMA-WHITELIST
    elseif ($action === 'unwhitelist_device') {
        $raw_mac = strtolower(trim($_POST['mac']));
        fw_drop($raw_mac);
        unset($whitelist[$raw_mac]);
        pushToVault('whitelist.json', json_encode($whitelist));
        $message = "<div style='color: var(--success); margin-bottom: 20px; font-weight: bold;'>SUCCESS: God Mode revoked for $raw_mac.</div>";
    }

    // 4. TOGGLE ADGUARD DNS (OpenWrt nftables Edition)
    elseif ($action === 'toggle_dns') {
        $new_state = $_POST['adblock_state'];
        
        // Remove old AdGuard rules if they exist
        exec("nft delete chain inet pisowifi adguard_dns 2>/dev/null");
        
        if ($new_state === 'on') {
            // Apply new AdGuard rules to intercept port 53 and redirect to 94.140.14.14
            exec("nft add chain inet pisowifi adguard_dns { type nat hook prerouting priority dstnat - 2\; policy accept\; }");
            exec("nft add rule inet pisowifi adguard_dns udp dport 53 dnat to 94.140.14.14");
            exec("nft add rule inet pisowifi adguard_dns tcp dport 53 dnat to 94.140.14.14");
            $message = "<div style='color: var(--success); margin-bottom: 20px; font-weight: bold;'>SUCCESS: AdGuard DNS Activated!</div>";
        } else {
            $message = "<div style='color: var(--danger); margin-bottom: 20px; font-weight: bold;'>SUCCESS: AdGuard DNS Disabled.</div>";
        }
        pushToVault('dns.json', json_encode(["adblock" => $new_state]));
    }
}

$current_dns = json_decode(pullFromVault('dns.json'), true);
$is_on = ($current_dns['adblock'] === 'on');

// 📡 NETWORK RADAR (OpenWrt DHCP Leases)
$connected_devices = [];
$lease_file = '/tmp/dhcp.leases';

if (file_exists($lease_file)) {
    $lines = file($lease_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $parts = explode(' ', $line);
        if (count($parts) >= 4) {
            $expiry = ($parts[0] == 0) ? 'Infinite' : date('Y-m-d H:i:s', (int)$parts[0]);
            $mac = strtolower(trim($parts[1]));
            $ip = $parts[2];
            $hostname = ($parts[3] === '*') ? 'Unknown Device' : $parts[3];
            $connected_devices[$mac] = ['ip' => $ip, 'hostname' => $hostname, 'lease' => $expiry];
        }
    }
}

require_once 'header.php';
?>

<div style="margin-bottom: 30px;">
    <h1 style="color: var(--warning); text-shadow: 0 0 10px var(--warning);">⚡ NETWORK & DNS SECURITY</h1>
    <p style="color: #888;">Manage network rules, AdBlock, and Whitelist VIP devices (ESP32, Admin Phones).</p>
</div> 

<?php echo $message; ?>

<!-- 🔥 NATIVE LUCI WIRELESS BRIDGE 🔥 -->
<div class="card" style="max-width: 500px; margin-bottom: 20px; border-color: var(--info); box-shadow: 0 0 15px rgba(0,243,255,0.1);">
    <h3 style="color: var(--info); border-bottom: 1px solid rgba(0,243,255,0.2); padding-bottom: 10px; margin-top: 0;">
        📶 WIRELESS RADIO SETTINGS
    </h3>
    <p style="font-size: 0.85rem; color: #aaa; margin-bottom: 15px; line-height: 1.4;">
        For system stability, changing SSIDs, Passwords, Channel Widths, and Band bindings (5G/2.4G) must be done through the native OpenWrt configuration engine. 
    </p>
    <button type="button" class="btn outline" style="width: 100%; border-color: var(--info); color: var(--info);" onclick="window.open('http://<?php echo $router_ip; ?>/cgi-bin/luci/admin/network/wireless', '_blank')">
        OPEN SECURE LUCI PANEL 🚀
    </button>
</div>

<!-- DNS CONTROLLER -->
<div class="card" style="max-width: 500px; margin-bottom: 30px; border-color: <?php echo $is_on ? 'var(--success)' : 'var(--danger)'; ?>;">
    <h3 style="color: <?php echo $is_on ? 'var(--success)' : 'var(--danger)'; ?>; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-top: 0;">
        ADGUARD DNS FILTERING: <?php echo $is_on ? 'ACTIVE' : 'DISABLED'; ?>
    </h3>
    <form method="POST">
        <input type="hidden" name="action" value="toggle_dns">
        <input type="hidden" name="adblock_state" value="<?php echo $is_on ? 'off' : 'on'; ?>">
        <button type="submit" class="btn <?php echo $is_on ? 'btn-danger' : 'btn-success'; ?>" style="width: 100%; margin-top: 15px;">
            <?php echo $is_on ? 'TURN OFF ADBLOCK' : 'ACTIVATE ADGUARD DNS'; ?>
        </button>
    </form>
</div>

<!-- CONNECTED DEVICES RADAR -->
<div class="card" style="width: 100%; overflow-x: auto;">
    <h3 style="color: var(--info); border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-bottom: 15px; margin-top: 0;">
        📡 LIVE CONNECTED DEVICES (DHCP/ARP)
    </h3>
    
    <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem;">
        <thead>
            <tr style="background: rgba(255,255,255,0.05); color: var(--theme-color);">
                <th style="padding: 12px; border-bottom: 1px solid #444;">HOSTNAME</th>
                <th style="padding: 12px; border-bottom: 1px solid #444;">IP ADDRESS</th>
                <th style="padding: 12px; border-bottom: 1px solid #444;">MAC ADDRESS</th>
                <th style="padding: 12px; border-bottom: 1px solid #444;">STATUS</th>
                <th style="padding: 12px; border-bottom: 1px solid #444; text-align: right;">ACTIONS</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($connected_devices)): ?>
                <tr>
                    <td colspan="5" style="padding: 20px; text-align: center; color: #888;">No devices detected on the network.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($connected_devices as $mac => $data): ?>
                    <?php $is_whitelisted = isset($whitelist[$mac]); ?>
                    <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); background: <?php echo $is_whitelisted ? 'rgba(176, 38, 255, 0.1)' : 'transparent'; ?>;">
                        <td style="padding: 12px; color: #fff;"><?php echo htmlspecialchars($data['hostname']); ?></td>
                        <td style="padding: 12px; color: var(--info); font-family: monospace;"><?php echo htmlspecialchars($data['ip']); ?></td>
                        <td style="padding: 12px; color: #ccc; font-family: monospace;"><?php echo strtoupper(htmlspecialchars($mac)); ?></td>
                        <td style="padding: 12px;">
                            <?php if ($is_whitelisted): ?>
                                <span style="color: #b026ff; font-weight: bold; font-size: 0.8rem;">⚡ PERMA-WHITELISTED</span>
                            <?php else: ?>
                                <span style="color: #888; font-size: 0.8rem;"><?php echo htmlspecialchars($data['lease']); ?></span>
                            <?php endif; ?>
                        </td>
                        <td style="padding: 12px; text-align: right; display: flex; gap: 10px; justify-content: flex-end;">
                            
                            <?php if ($is_whitelisted): ?>
                                <form method="POST" style="margin: 0;">
                                    <input type="hidden" name="action" value="unwhitelist_device">
                                    <input type="hidden" name="mac" value="<?php echo htmlspecialchars($mac); ?>">
                                    <button type="submit" class="btn btn-warning" style="padding: 5px 15px; font-size: 0.8rem;">REVOKE PERMA</button>
                                </form>
                            <?php else: ?>
                                <form method="POST" style="margin: 0;">
                                    <input type="hidden" name="action" value="whitelist_device">
                                    <input type="hidden" name="mac" value="<?php echo htmlspecialchars($mac); ?>">
                                    <button type="submit" class="btn" style="background: #b026ff; color: #fff; padding: 5px 15px; font-size: 0.8rem; border: none; font-weight: bold;">GRANT PERMA</button>
                                </form>
                                <form method="POST" style="margin: 0;" onsubmit="return confirm('WARNING: This will instantly expire their Vault session and disconnect them. Proceed?');">
                                    <input type="hidden" name="action" value="kick_device">
                                    <input type="hidden" name="mac" value="<?php echo htmlspecialchars($mac); ?>">
                                    <button type="submit" class="btn btn-danger" style="padding: 5px 15px; font-size: 0.8rem;">KICK</button>
                                </form>
                            <?php endif; ?>
                            
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
